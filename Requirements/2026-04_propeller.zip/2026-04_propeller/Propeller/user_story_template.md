# Reusable User Story Template

Prepared for: Business Analysis and Solution Design  
Date: 2026-04-09

## Purpose
This template is designed to be reused across user categories such as Customer, Agent, Finance Employee, Regulatory Officer, Legal Officer, and partner roles.

---

## Story Metadata
- Story ID:
- User Category:
- Story Title:
- Module / Journey:
- Priority:
- Channel: Web / Mobile / Desktop / Back Office
- Release / Phase:

## User Story
**As a** [user role]  
**I want to** [goal / action]  
**So that** [business value / expected outcome]

## Business Context
- Objective:
- Business value:
- Trigger / reason:
- Frequency of use:

## Preconditions
- [condition 1]
- [condition 2]
- [condition 3]

## Acceptance Criteria
1. Given [context], when [action], then [outcome]
2. Given [context], when [action], then [outcome]
3. Given [context], when [action], then [outcome]

## Business Rules
- [rule 1]
- [rule 2]
- [rule 3]

## Data Requirements
- Inputs:
- Validations:
- Outputs:
- Notifications:

## Exceptions / Edge Cases
- [edge case 1]
- [edge case 2]
- [edge case 3]

## Dependencies
- Systems:
- Teams:
- Approvals:

## Simple ASCII Sequence Diagram
Use a simple sequence that business and technical teams can read quickly.

```text
Actor         System/UI        Service/Module        Data Store/External
 |                |                  |                     |
 |-- action ----->|                  |                     |
 |                |-- request ------>|                     |
 |                |                  |-- read/write ----->|
 |                |                  |<----- response -----|
 |                |<----- result ----|                     |
 |<-- outcome ----|                  |                     |
```

## Sequence Notes
- Keep to 4 or fewer participants where possible.
- Use plain business labels such as Customer, Portal, Policy Service, Payment Service.
- Show only the main success path unless an exception is important.
- Use one diagram per story.

## Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design / development / QA

---

## Example Naming Convention
- Customer: CUST-001, CUST-002
- Finance: FIN-001, FIN-002
- Legal: LEG-001, LEG-002
- Regulatory: REG-001, REG-002

## Suggested Authoring Guidance
- Write one business objective per story.
- Avoid combining multiple journeys in one story.
- Make acceptance criteria testable.
- Keep diagrams short and readable.
- Use language understandable by business, QA, and engineering teams.
