# Technology Stack Recommendation v1.0

Prepared by: Business Analysis Support  
Date: 2026-04-09

## POC Scope
**3-Story Fast Demo (Option A)**
1. `CUST-001` Register account
2. `CUST-004` Request quote
3. `CUST-005` Purchase policy online

---

## Technology Stack Components Required

### 1. Cloud Platform / Hosting
### 2. Frontend / Customer Portal
### 3. Backend / API Services
### 4. Database
### 5. Authentication & Security
### 6. Security Stack (MFA, FIDO 2.0, Encryption, API Security)
### 7. Business Logic Engine (Quote)
### 8. Payment Gateway
### 9. Notifications
### 10. Monitoring & Logging

---

## Component 1: Cloud Platform / Hosting

### Option 1A: Free Tier Exploration (Recommended for True POC on Zero Budget)

#### Best Free-Tier Combination
**For a completely FREE 3-story POC, use this stack:**

**Frontend + Backend Hosting:**
- **Vercel** (Next.js native, free tier) - Includes free serverless functions
- Cost: **$0/month**

**Database:**
- **Supabase** (PostgreSQL managed, free tier)
  - 500MB storage free
  - 2 concurrent connections
  - Cost: **$0/month**

**Alternative Database:**
- **PlanetScale** (MySQL, free tier)
  - 5GB storage free
  - Cost: **$0/month**

**Authentication:**
- **Supabase Auth** (built-in, free tier)
  - Supports email/password, OAuth, passwordless
  - Cost: **$0/month**

**Email Notifications:**
- **SendGrid** (free tier)
  - 100 emails/day limit
  - Cost: **$0/month**

**Payment Processing:**
- **Stripe** (test keys - no fees during POC)
  - Cost: **$0/month** (testing phase)

**Monitoring/Logging:**
- **Vercel Analytics** (free tier)
- **Supabase Logs** (included)
  - Cost: **$0/month**

---

## **Total Cost for Free-Tier POC: $0/month**

**Limitations to be aware of:**
- Supabase: 2 concurrent connections (enough for POC demos)
- Supabase: 500MB storage (sufficient for test data)
- SendGrid: 100 emails/day (enough for daily POC testing)
- Vercel: Limited serverless function time (12 seconds timeout - may need optimization)
- Free tier databases auto-pause after 1 week of inactivity (restart required)

---

#### Architecture with Free Tiers
```text
Users (Browser) --- Vercel (free Next.js hosting)
    |
    v
[Vercel Serverless Functions] (API routes, built-in)
    |
    +-- Supabase Auth (email/password, OAuth)
    |
    +-- NextAuth.js + Supabase Auth
    |
    +-- Rate limiting middleware
    |
    +-- CORS enforcement
    |
    v
[Supabase PostgreSQL] (free: 500MB storage, 2 connections)
    |
    +-- Field-level encryption (built-in)
    |
    v
[SendGrid API] (free: 100 emails/day)
    |
    v
[Stripe API] (test keys, no fees)
```

**Viability:** ✅ **Yes, fully viable for 3-story POC demo**

**Demo Scenario:**
- 3–5 demo users
- ~50 emails during POC (registrations, confirmations, quotes)
- Well within free tier limits

---

### Option 1B: AWS Free Tier (12 months)

**Services needed:**
- EC2 t3.micro (1 free year)
- RDS db.t3.micro (1 free year, 20GB storage)
- Lambda (1M requests free/month)
- S3 (5GB free)
- CloudWatch (free logs)

**Estimated Monthly Cost after year 1:**
- EC2: $10–20/month
- RDS: $30–50/month
- Lambda: $0 (usually)
- **Total Year 1: $0 / Year 2+: ~$40–70/month**

**Pros:**
- 12 months truly free (no credit card restrictions after)
- More powerful than Vercel/Supabase free tiers
- Can handle more concurrent users

**Cons:**
- Auto-renewal after 12 months (need to plan migration)
- More complex to set up
- Free tier limits enforced strictly

**Best for:** Longer POC duration or if you want production-grade infrastructure from start

---

### Option 1C: Google Cloud (GCP) Free Tier

**Services needed:**
- Cloud Run (serverless containers, 2M requests/month free)
- Cloud SQL (db.f1-micro free tier)
- Cloud Storage (5GB free)
- Cloud Functions (2M invocations/month free)

**Estimated Monthly Cost:**
- Most services: **$0/month** (within free tier)
- Storage overage: minimal

**Pros:**
- Very generous free tier
- Good for containerized apps
- Excellent for data processing

**Cons:**
- Slightly steeper learning curve
- Less intuitive than Vercel for Next.js

---

### Option 1D: Azure Free Tier

**Services needed:**
- App Service (1 free instance, limited specs)
- Azure SQL Database (20GB free for first month, then paid)
- Azure Storage (5GB free)

**Estimated Monthly Cost:**
- App Service: $0 (limited)
- Azure SQL: $5–20/month
- **Total: ~$5–20/month after free tier**

**Pros:**
- Good for .NET apps
- Strong free tier for learning

**Cons:**
- Limited free tier duration
- SQL database not truly free

---

### Option 1E: Hybrid Free-Tier Approach (Most Practical)

**Combine best free offerings:**

| Component | Service | Cost | Notes |
|-----------|---------|------|-------|
| Frontend + Backend | Vercel | $0 | Next.js optimized |
| Database | Supabase | $0 | PostgreSQL, 500MB |
| Auth | Supabase Auth | $0 | Built-in to Supabase |
| Email | SendGrid | $0 | 100/day limit |
| Payments | Stripe | $0 | Test keys |
| Monitoring | Vercel + Supabase | $0 | Built-in |
| WAF / Security | Vercel built-in | $0 | Basic DDoS, HTTPS |

**Total: $0/month**

**Deployment diagram:**
```text
GitHub (source code)
    |
    v
[Vercel] Auto-deploys on git push
    |-- Automatic HTTPS/TLS
    |-- Serverless functions (Node.js)
    |-- Built-in DDoS protection
    |-- Environment variables for secrets
    |
    v
[Supabase PostgreSQL] (auto-backups)
    |-- Row Level Security (RLS)
    |-- Real-time capabilities included
    |-- Built-in PostgREST API
    |
    v
[External APIs]
    +-- Stripe (test mode)
    +-- SendGrid (free tier)
```

---

## **RECOMMENDATION: Option 1E - Hybrid Free-Tier Stack**

**For a true zero-cost, cloud-agnostic POC, use:**

1. **Frontend + Backend:** Vercel (Next.js)
2. **Database:** Supabase (PostgreSQL)
3. **Auth:** Supabase Auth or NextAuth.js
4. **Email:** SendGrid
5. **Payments:** Stripe test mode
6. **Total cost: $0/month**

**Why this is best:**
- ✅ **Zero cost** for the entire POC
- ✅ **Production-grade** (not toy services)
- ✅ **No credit card** required (Vercel and Supabase are truly free, not limited trials)
- ✅ **No auto-upgrade** surprises
- ✅ **Cloud-agnostic** (can migrate to any cloud later)
- ✅ **Minimal DevOps** (no infrastructure management)
- ✅ **Easy scaling** (if needed after POC)
- ✅ **Industry standard** (Vercel + Supabase is common stack)

**Upgrade path if POC succeeds:**
- Vercel: Stay free or upgrade to Pro ($20/month)
- Supabase: Upgrade to paid ($25+/month)
- Or migrate to AWS, Azure, GCP as needed

---

### Comparison Table: Free Tiers

| Cloud | Frontend | Database | Auth | Cost | Limitations | Best For |
|-------|----------|----------|------|------|------------|----------|
| **Vercel + Supabase** | Vercel ($0) | Supabase ($0) | Supabase ($0) | **$0** | 500MB DB, 2 connections | ⭐ Recommended |
| **AWS** | EC2/App Runner | RDS | Cognito | **$0 Year 1** | 12 month limit | Longer POC, AWS path |
| **GCP** | Cloud Run | Cloud SQL | Cloud Auth | **~$0** | Generous free tier | Data-heavy POCs |
| **Azure** | App Service | SQL Database | AD B2C | **~$5–20** | Limited duration | .NET apps |
| **Heroku** | Removed free tier | N/A | N/A | **Paid only** | ❌ Not recommended |

---

## Updated Component List with Free Options

### Component 1: Cloud Platform / Hosting

#### Recommended: Vercel (Free Tier)
**Cost:** $0/month (truly free, no time limit)

**Included in free tier:**
- Unlimited deployments
- Automatic HTTPS
- Serverless functions (Node.js)
- Edge caching
- Built-in DDoS protection
- Environment variables

**Deployment:**
```bash
# Auto-deploy on git push
git push origin main
# Vercel automatically builds and deploys
# Live in seconds
```

**Pros:**
- ✅ Zero cost
- ✅ Made for Next.js
- ✅ Instant deployments
- ✅ Preview URLs for each PR
- ✅ Includes serverless functions
- ✅ No credit card required

**Cons:**
- ⚠️ Function timeout: 12 seconds (enough for POC)
- ⚠️ Limited to Node.js runtime

---

### Component 4: Database

#### Recommended: Supabase (Free Tier)
**Cost:** $0/month (no time limit)

**Included in free tier:**
- 500MB storage
- 2GB bandwidth
- 2 concurrent connections
- PostgreSQL with built-in extensions
- Row Level Security (RLS)
- Real-time capabilities
- RestAPI auto-generated
- Authentication included
- Basic backups

**Connection:**
```typescript
// Next.js API route
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

const { data, error } = await supabase
  .from('policies')
  .select('*')
  .eq('customer_id', customerId)
```

**Pros:**
- ✅ Zero cost
- ✅ Real PostgreSQL (not limited SQL)
- ✅ Built-in auth (good alternative to NextAuth.js)
- ✅ Real-time updates included
- ✅ Auto-generated REST API
- ✅ Backups included

**Cons:**
- ⚠️ 2 concurrent connections (enough for demo)
- ⚠️ Auto-pauses after 1 week inactivity (restart needed)
- ⚠️ 500MB might be tight for production, fine for POC

---

### Alternative: PlanetScale (Free Tier - MySQL)
**Cost:** $0/month

**Included in free tier:**
- 5GB storage
- 3 databases
- MySQL 8.0
- Automatic backups

**Comparison:**
- PlanetScale has larger free DB (5GB vs 500MB)
- Supabase includes auth + real-time
- For this POC: **Supabase is better** (auth built-in)

---

### Component 5 & 6: Authentication & Security

#### Recommended: Supabase Auth (Built-in)
**Cost:** $0/month (included with Supabase)

**Features included:**
- Email/password
- Magic link (passwordless)
- OAuth (Google, GitHub, etc.)
- Session management
- JWT tokens
- Row-level security

**Alternatively: NextAuth.js**
**Cost:** $0/month (open source)

**Features:**
- Same as above
- More flexible
- Can add own identity provider

---

## Updated Total Cost for Free POC

| Component | Technology | Cost |
|-----------|-----------|------|
| Frontend + Backend | Vercel | **$0** |
| Database | Supabase PostgreSQL | **$0** |
| Authentication | Supabase Auth | **$0** |
| Email | SendGrid free tier | **$0** |
| Payment Gateway | Stripe test keys | **$0** |
| Monitoring | Vercel + Supabase | **$0** |
| Security (TLS, MFA, WAF) | Built-in | **$0** |
| **TOTAL** | | **$0/month** |

---

## Recommended Free-Tier Tech Stack

```
┌─ GitHub (free) - code hosting
│
├─→ Vercel (free) - auto-deploys Next.js
│   ├─ Frontend (React)
│   ├─ API routes (backend)
│   ├─ Serverless functions
│   └─ Auto HTTPS/TLS
│
├─→ Supabase (free) - PostgreSQL + Auth
│   ├─ Database (500MB)
│   ├─ Authentication
│   ├─ Row-level security
│   ├─ Real-time (bonus)
│   └─ REST API auto-generated
│
├─→ SendGrid (free) - Email notifications
│   └─ 100 emails/day
│
├─→ Stripe (free) - Payment processing
│   └─ Test mode (no fees)
│
└─→ Monitoring (built-in)
    ├─ Vercel Analytics
    ├─ Supabase Logs
    └─ No additional cost
```

---

## Deployment Timeline with Free Tiers

**Week 1: Setup**
- Create Vercel account (connect GitHub)
- Create Supabase account
- Initialize Next.js project
- Deploy skeleton app to Vercel

**Week 2: Core Features**
- Implement CUST-001 (register)
- Connect Supabase Auth
- Create database schema

**Week 3: Business Logic**
- Implement CUST-004 (quote)
- Implement CUST-005 (purchase)
- Stripe test integration

**Week 4: Polish & Demo**
- Email notifications (SendGrid)
- Error handling
- Security hardening
- Demo to stakeholders

---

## Important Notes for Free-Tier POC

### Database Limitations
- **2 concurrent connections:** Not an issue for POC demo (max 3–5 simultaneous users)
- **500MB storage:** Enough for test data (100 policies = ~100KB)
- **Auto-pause after 1 week:** Requires manual restart (fine for POC)

### Email Limitations
- **100 emails/day:** Enough for demo (typical POC uses ~5–10 emails)
- Upgrade during demo if needed ($0 to $5/month)

### Function Timeout
- **12 seconds (Vercel):** Sufficient for quotes and policy creation
- Most operations complete in <2 seconds

---

## Migration Path if POC Succeeds

**Month 1–3: POC (Free)**
- Use free tiers as above
- Cost: **$0**

**Month 4+: Pilot (Low-cost)**
- Upgrade Vercel if needed: **$20/month**
- Upgrade Supabase: **$25/month**
- Stripe: **2.9% + $0.30 per transaction**
- **Total: ~$50–100/month**

**Month 12+: Production (Choose cloud)**
- Migrate to AWS, Azure, or GCP if needed
- Or stay with Vercel + Supabase (they scale)

---

## Final Recommendation

**Use the Free-Tier Hybrid Stack:**

```
Vercel (free) + Supabase (free) + SendGrid (free) + Stripe (free)
= Complete 3-story POC for $0/month
```

**Why:**
1. ✅ **Zero cost** - No budget needed for POC
2. ✅ **Production-grade** - Same tools used by real companies
3. ✅ **Cloud-agnostic** - Not locked into AWS/Azure/GCP
4. ✅ **Scalable** - Grows with demand
5. ✅ **Easy migration** - Move anywhere later if needed
6. ✅ **Minimal DevOps** - Focus on features, not infrastructure

**You can explore AWS, Azure, or GCP later if needed, but start free.**


- Many service options to choose from

---

### Option C: Google Cloud Platform (GCP)
**Services needed:**
- Cloud Run (serverless containers)
- Cloud SQL (managed database)
- Cloud Storage
- Cloud Functions

**Estimated Monthly Cost:**
- Cloud Run: $10–30/month
- Cloud SQL: $40–150/month
- Cloud Storage: $3–10/month
- Cloud Functions: $5–15/month
- **Total: ~$58–205/month**

**Pros:**
- Competitive pricing
- Excellent Kubernetes support
- Good for data processing

**Cons:**
- Smaller ecosystem than AWS
- Less enterprise adoption

---

### Option D: Heroku (Platform as a Service)
**Services needed:**
- Heroku Dynos (app hosting)
- Heroku Postgres (database)
- Add-ons (SendGrid for email, etc.)

**Estimated Monthly Cost:**
- 1 Standard Dyno: $50/month
- Postgres: $50/month
- Add-ons: $20–50/month
- **Total: ~$120–150/month**

**Pros:**
- Very fast to deploy
- Built-in CI/CD
- Minimal DevOps required

**Cons:**
- More expensive per unit
- Less flexibility
- Limited scalability

---

## **Recommendation: Option B - AWS**
**For a POC, AWS is the best choice because:**
- Lowest total cost of ownership ($58–220/month)
- Excellent free tier for learning
- Largest community and documentation
- Flexible pricing matches POC requirements exactly

---

## Component 2: Frontend / Customer Portal

### Option A: React.js
**Stack:**
- React 18
- TypeScript
- Tailwind CSS (styling)
- React Router (navigation)
- Axios (HTTP client)

**Cost:** $0 (open source)

**Pros:**
- Industry standard
- Large ecosystem
- Easy to find developers
- Great state management options (Redux, Zustand)

**Cons:**
- Steeper learning curve
- Requires build tools (Webpack, Vite)

---

### Option B: Angular
**Stack:**
- Angular 16+
- TypeScript (built-in)
- RxJS (reactive programming)
- Angular Material (UI components)

**Cost:** $0 (open source)

**Pros:**
- Full-featured framework
- Built-in dependency injection
- Great for enterprise

**Cons:**
- Heavier framework
- Longer development time
- Steeper learning curve

---

### Option C: Vue.js
**Stack:**
- Vue 3
- TypeScript
- Tailwind CSS
- Vue Router (navigation)

**Cost:** $0 (open source)

**Pros:**
- Easiest to learn
- Smaller bundle sizes
- Great developer experience
- Progressive framework

**Cons:**
- Smaller community than React
- Fewer third-party libraries

---

### Option D: Next.js (React-based full-stack)
**Stack:**
- Next.js 13+ (React + SSR + API routes)
- TypeScript
- Tailwind CSS

**Cost:** $0 (open source)

**Pros:**
- Full-stack JavaScript
- Built-in SEO optimization
- API routes (no separate backend needed initially)
- Excellent developer experience
- Server-side rendering for performance

**Cons:**
- Newer pattern for some teams
- Requires Node.js for backend API routes

---

## **Recommendation: Option D - Next.js**
**For this POC, Next.js is the best choice because:**
- **Single codebase** reduces complexity (frontend + API routes together)
- **Fastest time to market** (no separate backend framework setup needed)
- **Built-in API routes** eliminate need for Express or separate API framework initially
- **Modern developer experience** (TypeScript, hot reload, easy deployment)
- **Minimal infrastructure** (can run on single host or serverless)

---

## Component 3: Backend / API Services

### Option A: Node.js + Express.js
**Stack:**
- Express.js (web framework)
- TypeScript
- Sequelize or TypeORM (ORM)

**Cost:** $0 (open source)

**Pros:**
- JavaScript across full stack
- Fast to develop
- Good ecosystem
- Lightweight

**Cons:**
- Less mature than some alternatives
- Not ideal for CPU-heavy operations

---

### Option B: .NET 7+ (C#)
**Stack:**
- ASP.NET Core 7+
- Entity Framework Core (ORM)
- C#

**Cost:** $0 (open source)

**Pros:**
- Strong typing
- Enterprise-ready
- Excellent performance
- Good for Windows-heavy environments

**Cons:**
- Steeper learning curve for non-.NET teams
- Larger resource footprint

---

### Option C: Python + FastAPI
**Stack:**
- FastAPI (web framework)
- SQLAlchemy (ORM)
- Python 3.9+

**Cost:** $0 (open source)

**Pros:**
- Fast API development
- Automatic API documentation (Swagger)
- Clean, readable code
- Good for data processing

**Cons:**
- Slower execution than compiled languages
- Deployment complexity

---

### Option D: Next.js API Routes (Recommended Option)
**Stack:**
- Next.js 13+ API Routes
- TypeScript
- Prisma ORM
- Node.js runtime

**Cost:** $0 (open source)

**Pros:**
- **No separate framework needed**
- **API and frontend in same codebase**
- **Single deployment**
- **TypeScript for type safety**
- **Easy testing**

**Cons:**
- Not suitable for very large backend systems
- Limited to Node.js runtime

---

## **Recommendation: Option D - Next.js API Routes**
**For this POC, use Next.js API Routes because:**
- **Eliminates separate backend deployment**
- **Reduces infrastructure complexity**
- **Faster initial development**
- **Easier to scale later (separate if needed)**
- **One team can manage full stack**

---

## Component 4: Database

### Option A: PostgreSQL (Relational)
**Deployment:**
- AWS RDS PostgreSQL: $30–150/month
- Self-managed: $5–10/month (compute only)

**Cost:** $30–150/month (managed)

**Pros:**
- Robust, reliable
- Great for structured insurance data
- Excellent JSON support
- Open source

**Cons:**
- Requires more schema planning upfront

---

### Option B: MySQL
**Deployment:**
- AWS RDS MySQL: $30–150/month

**Cost:** $30–150/month (managed)

**Pros:**
- Very popular
- Good performance
- Widely supported

**Cons:**
- Slightly less feature-rich than PostgreSQL

---

### Option C: MongoDB (NoSQL)
**Deployment:**
- MongoDB Atlas: $0–500+/month (depends on storage)
- Free tier: up to 512MB

**Cost:** $0–100/month (free tier for POC)

**Pros:**
- Flexible schema
- Scales horizontally
- Good for rapid prototyping

**Cons:**
- Less suitable for structured insurance data
- Transaction support is newer

---

### Option D: DynamoDB (AWS NoSQL)
**Cost:** $1–50/month (on-demand pricing for POC)

**Pros:**
- Serverless, auto-scaling
- No provisioning needed
- Good integration with AWS ecosystem

**Cons:**
- Vendor lock-in (AWS only)
- Complex pricing model
- Less suitable for relational insurance data

---

## **Recommendation: Option A - PostgreSQL**
**For this insurance POC, PostgreSQL is best because:**
- **Relational structure fits insurance data** (policies, customers, quotes)
- **ACID compliance** ensures data integrity (critical for financial data)
- **Strong ecosystem** (ORMs like Prisma, TypeORM)
- **Cost-effective** for small scale ($30/month managed)
- **Scales easily** if needed later

---

## Component 6: Security Stack (MFA, FIDO 2.0, Encryption, API Security)

### Option A: Multi-Factor Authentication (MFA) with FIDO 2.0 / WebAuthn

#### 1. FIDO 2.0 / WebAuthn (Hardware Tokens & Biometric)
**Cost:** $0 (browser native, hardware token ~$20–50 per user if purchased separately)

**Tools:**
- `@simplewebauthn/browser` & `@simplewebauthn/server` (open source)
- AWS Cognito native WebAuthn support
- NextAuth.js FIDO2 plugin

**Pros:**
- **Phishing-resistant** (cryptographic binding to domain)
- Industry standard (FIDO2 Alliance)
- Works with security keys (YubiKey), phones, fingerprint readers
- No SMS interception risk
- Industry leading for financial/insurance apps

**Cons:**
- Requires user hardware purchase for keys (optional)
- Slightly higher initial setup complexity
- Not all users familiar with the flow

**Recommended:** ✅ **Include in POC** (optional second factor)

---

#### 2. TOTP (Time-based One-Time Password)
**Cost:** $0 (open source)

**Tools:**
- `speakeasy` (Node.js library)
- `qrcode` (for QR code generation)
- Works with Google Authenticator, Authy, Microsoft Authenticator

**Pros:**
- Very simple to implement
- Free for users (use phone authenticator apps)
- Industry standard
- Reliable, no network needed

**Cons:**
- Not as secure as FIDO2 (can be intercepted)
- Users can lose access if phone is lost

**Recommended:** ✅ **Include as backup MFA**

---

#### 3. SMS / Email OTP (One-Time Password)
**Cost:** SendGrid (email): $0 free tier | Twilio (SMS): $0.01–0.03 per SMS

**Tools:**
- SendGrid API (email)
- Twilio (SMS)
- `node-otp` library

**Pros:**
- Easiest for users
- Works on any phone
- Good fallback option

**Cons:**
- SMS vulnerable to interception/SIM swapping
- Additional cost at scale
- Slower than TOTP/FIDO2

**Recommended:** ✅ **Include as fallback only**

---

### Option B: API Security (Rate Limiting, JWT, API Keys)

#### 1. JWT (JSON Web Tokens) with Signing
**Cost:** $0 (built into NextAuth.js)

**Implementation:**
```typescript
// NextAuth.js automatically handles JWT signing
// Tokens signed with HS256 or RS256
```

**Pros:**
- Stateless authentication
- No server session storage needed
- Standard for APIs

**Cons:**
- Token revocation requires additional implementation
- Larger payload size

**Recommended:** ✅ **Standard for API authentication**

---

#### 2. Rate Limiting
**Cost:** $0 (open source) | AWS API Gateway: included

**Tools:**
- `express-rate-limit` (Node.js)
- `@upstash/ratelimit` (serverless-friendly)
- AWS API Gateway native throttling

**Pros:**
- Prevents brute force attacks
- DDoS mitigation
- Simple to implement

**Implementation:**
```typescript
// Limit registration to 5 per hour per IP
// Limit login attempts to 10 per hour per email
// Limit quote requests to 100 per day per user
```

**Recommended:** ✅ **Critical for API security**

---

#### 3. CORS (Cross-Origin Resource Sharing)
**Cost:** $0 (built-in)

**Tools:**
- `next-cors` or built-in Next.js middleware
- AWS API Gateway CORS settings

**Pros:**
- Prevents unauthorized cross-origin requests
- Simple configuration

**Implementation:**
```typescript
// Allow only your frontend domain
// Restrict to POST, GET for specific endpoints
```

**Recommended:** ✅ **Always enable with strict rules**

---

### Option C: Data Encryption

#### 1. TLS/SSL (Transport Security)
**Cost:** $0 (built-in with AWS/hosting)

**Tools:**
- AWS Certificate Manager (free)
- Let's Encrypt (free)

**Pros:**
- End-to-end encryption
- Industry standard
- Automatic with AWS

**Recommended:** ✅ **Always enable (HTTPS everywhere)**

---

#### 2. Database Encryption at Rest
**Cost:** $0–$10/month (varies by provider)

**Tools:**
- AWS RDS encryption (included)
- PostgreSQL native encryption
- AWS KMS (Key Management Service)

**Pros:**
- Protects data if storage is compromised
- Critical for financial data
- Regulatory requirement for insurance

**Recommended:** ✅ **Enable by default**

---

#### 3. Field-Level Encryption (Sensitive Data)
**Cost:** $0 (development time)

**Tools:**
- `libsodium` / `tweetsodium` (encryption library)
- `@aws-sdk/client-kms` (AWS KMS integration)

**What to encrypt:**
- SSN / Tax ID
- Bankaccount numbers
- Health information (if applicable)

**Pros:**
- Even if database is compromised, sensitive fields remain protected
- Complies with data minimization principles

**Recommended:** ✅ **For PII and financial data**

---

### Option D: Secrets Management

#### 1. AWS Secrets Manager
**Cost:** $0.40 per secret + $0.06 per 10,000 API calls (~$1–2/month for POC)

**Use cases:**
- Database passwords
- Stripe API keys
- SendGrid tokens
- JWT signing keys

**Pros:**
- Automatic rotation
- Audit trail
- Access control
- Integrates with Lambda/RDS

**Recommended:** ✅ **For production-grade POC**

---

#### 2. Environment Variables + Encryption
**Cost:** $0 (development practice)

**Tools:**
- `.env.local` files (never commit)
- `.env` file encryption libraries (`dotenv-encrypted`)
- GitHub Secrets (for CI/CD)

**Pros:**
- Simple for POC
- No additional cost
- Works everywhere

**Cons:**
- Less secure than Secrets Manager
- Harder to rotate secrets

**Recommended:** ⚠️ **For POC development only, upgrade to Secrets Manager for demo**

---

### Option E: WAF (Web Application Firewall)

#### 1. AWS WAF
**Cost:** $5/month + $0.60 per million requests (~$5–10/month for POC)

**Protection:**
- SQL injection
- Cross-site scripting (XSS)
- Bot attacks
- DDoS mitigation

**Pros:**
- Native AWS integration
- Automatic rule updates
- Good for financial applications

**Recommended:** ✅ **Highly recommended for insurance app**

---

#### 2. Cloudflare WAF (if using Cloudflare CDN)
**Cost:** $20/month (Pro plan)

**Pros:**
- Excellent DDoS protection
- Easy to manage
- Good reputation

**Cons:**
- Additional monthly cost

**Recommended:** ⚠️ **Optional, AWS WAF is sufficient**

---

### Option F: Logging & Audit Trail

#### 1. AWS CloudWatch Logs
**Cost:** $0.50 per GB ingested (~$5–10/month for POC)

**What to log:**
- All authentication events
- API access by user
- Payment transactions
- Policy changes
- Claims submissions

**Pros:**
- Integrated with AWS
- Searchable, queryable
- Retention policies available

**Recommended:** ✅ **Standard practice**

---

#### 2. Winston.js (Application-level logging)
**Cost:** $0 (open source)

**Use:**
- Structure logs in JSON format
- Easy searching and correlation
- Integration with CloudWatch

**Recommended:** ✅ **Use in Next.js app**

---

### Option G: Compliance & Data Privacy

#### 1. Data Encryption at Rest (Already covered)
#### 2. PII Masking in Logs
**Cost:** $0 (development practice)

**What to mask:**
- SSN: `XXX-XX-****`
- Email: `u***@example.com`
- Phone: `***-****-5678`

**Recommended:** ✅ **Always implement**

---

#### 3. GDPR / Privacy Compliance
**Tools:**
- Data retention policies (implement in database)
- Right to erasure (implement delete endpoints)
- Data portability (export user data endpoint)

**Recommended:** ✅ **Even in POC**

---

---

## Recommended Security Stack (for Insurance POC)

| Component | Technology | Cost | Priority |
|-----------|-----------|------|----------|
| **MFA - Primary** | FIDO 2.0 / WebAuthn (via NextAuth.js) | $0 | ⭐⭐⭐ Critical |
| **MFA - Backup** | TOTP (Google Authenticator) | $0 | ⭐⭐⭐ Critical |
| **MFA - Fallback** | Email OTP | $0–5/month | ⭐⭐ Secondary |
| **Transport** | TLS 1.3 (HTTPS) | $0 | ⭐⭐⭐ Critical |
| **API Authentication** | JWT (NextAuth.js) | $0 | ⭐⭐⭐ Critical |
| **API Security** | Rate limiting + CORS | $0 | ⭐⭐⭐ Critical |
| **Database Encryption** | AWS RDS + KMS | $0–10/month | ⭐⭐⭐ Critical |
| **Field Encryption** | libsodium (SSN, bank info) | $0 | ⭐⭐⭐ Critical |
| **Secrets Management** | AWS Secrets Manager | $1–2/month | ⭐⭐ Recommended |
| **Web Application Firewall** | AWS WAF | $5–10/month | ⭐⭐⭐ Critical |
| **Logging & Audit** | CloudWatch + Winston.js | $5–10/month | ⭐⭐⭐ Critical |
| **PII Masking** | Custom middleware | $0 | ⭐⭐⭐ Critical |

---

## Security Stack Implementation in Next.js POC

### Architecture Example
```text
User Browser (HTTPS)
    |
    v
[Next.js App with NextAuth.js]
    |
    +-- WebAuthn (FIDO2) registration & verification
    |
    +-- TOTP backup factor
    |
    +-- Rate limiting middleware (max 5 failed logins)
    |
    +-- JWT token generation + signing
    |
    v
[AWS WAF] - Blocks malicious requests
    |
    v
[API Routes with validation]
    |
    +-- Input validation (prevent SQL injection, XSS)
    |
    +-- User authorization checks
    |
    +-- Audit logging to CloudWatch
    |
    v
[AWS RDS PostgreSQL]
    |
    +-- Encrypted at rest (AWS KMS)
    |
    +-- Field-level encryption for SSN, payment info
    |
    v
[AWS Secrets Manager]
    |
    +-- Database credentials
    |
    +-- Stripe API keys
    |
    +-- SendGrid tokens
```

---

## Security Implementation Quick Start for POC

### Week 1: Foundation
1. **Enable HTTPS** (automatic with AWS)
2. **Implement JWT** (NextAuth.js built-in)
3. **Add rate limiting** (express-rate-limit)
4. **Enable database encryption** (AWS RDS)

### Week 2: MFA
1. **Add FIDO2/WebAuthn** (simplewebauthn library)
2. **Add TOTP backup** (speakeasy library)
3. **Test MFA flows**

### Week 3: Advanced Security
1. **Enable AWS WAF**
2. **Implement field-level encryption** (for SSN)
3. **Set up CloudWatch logging**
4. **Implement PII masking**

### Week 4: Compliance
1. **Data retention policies**
2. **Privacy endpoints** (delete, export)
3. **Audit trail verification**
4. **Security testing**

---

## Why Security is Critical for This POC

### Insurance Domain Requirements
- **Financial transactions** (requires highest security)
- **PII (Personally Identifiable Information)** (customer data protection required)
- **Regulatory compliance** (insurance is heavily regulated)
- **Customer trust** (security is a differentiator)

### POC Security Credibility
- **Shows thoughtfulness** to stakeholders (security from day 1, not retrofit)
- **Reduces future rework** (building secure from start is faster)
- **Meets compliance** (insurance regulators expect security)
- **Builds investor confidence** (if seeking funding)

---

## Summary

This insurance POC **must include**:
✅ FIDO 2.0 / WebAuthn (phishing-resistant MFA)  
✅ TOTP backup (user-friendly MFA)  
✅ TLS encryption (HTTPS)  
✅ Database encryption at rest (AWS KMS)  
✅ Field-level encryption (SSN, payment info)  
✅ JWT + rate limiting (API security)  
✅ AWS WAF (web application firewall)  
✅ CloudWatch logging (audit trail)  

**Security additions to tech stack cost:** ~$15–25/month (AWS WAF + KMS + CloudWatch + Secrets Manager)

**Total recommended monthly cost:** ~$115–165/month (was ~$100/month, security adds ~$15–25)

This is **industry best practice** for financial/insurance applications.


### Option B: AWS Cognito
**Cost:** $0–$5/month (free tier covers POC)

**Pros:**
- Native AWS integration
- Good for AWS stack
- Secure, enterprise-ready
- Reasonable pricing

**Cons:**
- AWS vendor lock-in
- Less flexible than Auth0
- Steeper learning curve

---

### Option C: NextAuth.js (Self-managed in Next.js)
**Cost:** $0 (open source)

**Pros:**
- No third-party dependencies
- Full control
- Works seamlessly with Next.js
- Flexible OAuth providers

**Cons:**
- Requires more security management
- Developer must handle session security

---

### Option D: Firebase Authentication
**Cost:** $0–$25/month (free tier covers POC)

**Pros:**
- Very fast to implement
- Multi-platform support
- Good for POCs
- Firebase ecosystem integration

**Cons:**
- Google vendor lock-in
- Less flexible for custom flows

---

## **Recommendation: Option C - NextAuth.js (for Next.js stack)**
**For this POC with Next.js, NextAuth.js is best because:**
- **Zero cost**
- **Perfect integration with Next.js**
- **Full control over user data** (stored in your PostgreSQL)
- **Standard OAuth/credential flows**
- **Can migrate to Auth0 later if needed**
- **No vendor lock-in**

---

## Component 6: Quote/Business Logic Engine

### Option A: Custom Business Logic Layer
**Stack:**
- Next.js API routes
- TypeScript business services
- Custom rule engine in code

**Cost:** $0 (development time only)

**Pros:**
- Full control
- No licensing costs
- Integrated with main codebase

**Cons:**
- Must build rule engine from scratch
- Scaling rule complexity is manual

---

### Option B: Drools (Open Source Rule Engine)
**Cost:** $0 (open source)

**Pros:**
- Mature rule engine
- DRL language for rules
- Good for complex insurance logic

**Cons:**
- Steep learning curve
- Requires separate JVM deployment
- Adds operational complexity

---

### Option C: AWS Lambda + Layers (Serverless)
**Cost:** $5–20/month

**Pros:**
- Scales automatically
- Pay per execution
- Good for event-driven processing

**Cons:**
- Cold start delays
- Requires AWS knowledge

---

## **Recommendation: Option A - Custom Business Logic in Next.js**
**For this POC, custom logic is best because:**
- **Simplest to implement** (no extra tools/frameworks)
- **Lives in same codebase as API**
- **Easy to test and debug**
- **Can be extracted to separate service later if needed**
- **For a 3-story POC, quote rules are simple enough**

**Example structure:**
```
/app/api/quotes/route.ts
  └─ /services/quoteEngine.ts
      ├─ calculatePremium(riskData)
      ├─ applyDiscounts(baseRate)
      └─ validateEligibility(customerData)
```

---

## Component 7: Payment Gateway

### Option A: Stripe
**Cost:** 2.9% + $0.30 per transaction (~$0.30–0.50 per $10 payment for POC)

**Pros:**
- Industry standard
- Excellent developer experience
- Great documentation
- Supports multiple payment methods
- Built-in webhooks for updates

**Cons:**
- Transaction fees
- Requires PCI compliance considerations

---

### Option B: PayPal
**Cost:** 2.9% + $0.30 per transaction

**Pros:**
- Very popular
- Customer familiar
- Good integration options
- Good for international

**Cons:**
- Similar fees to Stripe
- Documentation less polished

---

### Option C: Square
**Cost:** 2.9% + $0.30 per transaction

**Pros:**
- Good for in-person + online
- Easy integration
- US-focused, great support

**Cons:**
- Not as widely used internationally
- Similar fees

---

### Option D: Mock Payment Service (for POC only)
**Cost:** $0

**Pros:**
- No transaction fees
- Can demo without real payments
- Instant implementation

**Cons:**
- Not production-ready
- Customers can't actually pay

---

## **Recommendation: Option A - Stripe**
**For this POC, Stripe is best because:**
- **Easiest integration** (excellent Next.js libraries like `@stripe/stripe-js`)
- **Industry standard** (stakeholders recognize it)
- **Strong security** (PCI compliance handled)
- **Great webhooks** for order status updates
- **Free to test** (test keys, no real charges during POC)
- **Easy to scale** to production

---

## Component 8: Notifications (Email/SMS)

### Option A: SendGrid (Email)
**Cost:** $0 free tier (up to 100 emails/day)

**Pros:**
- Excellent for transactional email
- Good deliverability
- Great documentation
- Easy integration

**Cons:**
- Free tier limited
- Upgrade costs $20/month+

---

### Option B: AWS SES (Email)
**Cost:** $0.10 per 1000 emails (~free for POC)

**Pros:**
- Very cheap at scale
- Good if already on AWS
- Reliable

**Cons:**
- Less friendly UI
- No-reply initially (sandbox mode)

---

### Option C: Twilio (SMS)
**Cost:** $0.0075 per SMS (~free for POC with limited messages)

**Pros:**
- Industry standard for SMS
- Multi-channel (SMS, voice, video)
- Great APIs

**Cons:**
- Costs add up with volume
- Can be complex for simple needs

---

### Option D: Node Mailer + AWS SES
**Cost:** $0 (development time + minimal SES costs)

**Pros:**
- Lightweight
- Full control
- Very cheap
- Works with any SMTP

**Cons:**
- More setup required

---

## **Recommendation: Option A - SendGrid**
**For this POC, SendGrid is best because:**
- **Free tier covers POC** (100 emails/day is enough for testing)
- **Excellent templates** (account confirmation, quote, policy confirmation)
- **Reliable** (high deliverability)
- **Good integration** with Next.js
- **Easy to upgrade to paid** if needed later

---

## Complete Recommended Tech Stack (MVP POC)

| Component | Technology | Cost | Rationale |
|-----------|-----------|------|-----------|
| **Cloud/Hosting** | AWS | $58–120/month | Lowest cost, flexible |
| **Frontend + Backend** | Next.js 13+ | $0 | Full-stack, single codebase |
| **Database** | PostgreSQL (RDS) | $30–50/month | Relational, structured data |
| **Authentication** | NextAuth.js | $0 | Integrated, no vendor lock-in |
| **MFA - Primary** | FIDO 2.0 / WebAuthn | $0 | Phishing-resistant |
| **MFA - Backup** | TOTP (Google Authenticator) | $0 | User-friendly backup |
| **MFA - Fallback** | Email OTP | $0–5/month | Emergency access |
| **API Security** | JWT + Rate limiting | $0 | Standard practice |
| **Transport Security** | TLS 1.3 / HTTPS | $0 | End-to-end encryption |
| **Database Encryption** | AWS RDS + KMS | $5–10/month | Data at rest protection |
| **Field Encryption** | libsodium (PII) | $0 | SSN, payment info protection |
| **Secrets Management** | AWS Secrets Manager | $1–2/month | Credential rotation |
| **WAF** | AWS WAF | $5–10/month | Attack prevention |
| **Logging & Audit** | CloudWatch + Winston.js | $5–10/month | Compliance & troubleshooting |
| **Quote Engine** | Custom (in Next.js) | $0 | Simple, integrated |
| **Payments** | Stripe | $0–transaction fees | Industry standard, test-ready |
| **Email Notifications** | SendGrid | $0 (free tier) | Fast, reliable, transactional |
| **Monitoring** | AWS CloudWatch | Included | Integrated with AWS |

---

## Total Estimated Monthly Cost (POC Phase - with Security)
- AWS (compute + database): **$88–120/month**
- AWS WAF: **$5–10/month**
- AWS KMS + Secrets Manager: **$6–12/month**
- AWS CloudWatch: **$5–10/month** (included mostly)
- SendGrid (email): **$0** (free tier)
- Stripe transaction fees: **~$5–20/month** (if real payments processed)
- **Total: ~$115–165/month**

---

## Deployment Architecture (with Security)

```text
Users (Browser) --- HTTPS/TLS 1.3
    |
    v
[AWS CloudFront] (CDN, DDoS protection)
    |
    v
[AWS WAF] - Blocks SQL injection, XSS, DDoS, rate limiting
    |
    v
[AWS App Runner / EC2] (Next.js app with API routes)
    |
    +-- NextAuth.js with FIDO2/WebAuthn + TOTP
    |-- Rate limiting (max 5 login attempts per hour)
    |-- CORS enforcement
    |-- PII masking in logs
    |
    +-----> [AWS RDS PostgreSQL] (encrypted at rest with KMS)
    |       +-- Field-level encryption (SSN, payment info)
    |       +-- All changes audit logged
    |
    +-----> [AWS Secrets Manager] (credential rotation)
    |       +-- DB passwords, API keys, JWT secrets
    |
    +-----> [SendGrid API] (email notifications)
    |
    +-----> [Stripe API] (payment processing over HTTPS)
    |
    +-----> [AWS CloudWatch] (all API calls logged)
            +-- CloudWatch Logs (searchable audit trail)
            +-- CloudWatch Metrics (security alerts)
            +-- PII masked in logs for compliance
```

---

## Recommendation Summary

### Option 1: FREE-TIER STACK (Recommended for True POC)

**Use this tech stack:**
- **Frontend + Backend:** Next.js 13+ (React + API routes)
- **Hosting:** Vercel (free tier)
- **Database:** Supabase PostgreSQL (free tier)
- **Authentication:** Supabase Auth or NextAuth.js
- **MFA:** FIDO 2.0 (simplewebauthn library) + TOTP
- **API Security:** JWT, rate limiting, CORS, input validation
- **Data Protection:** TLS encryption (built-in), field-level encryption
- **Payments:** Stripe (test mode)
- **Email:** SendGrid (free tier: 100/day)
- **Monitoring:** Vercel + Supabase (built-in)

**Total estimated cost:** **$0/month** ✅

**Why choose free-tier stack:**
- ✅ Zero budget requirement for POC
- ✅ Production-grade tools (not toys)
- ✅ Cloud-agnostic (migrate anywhere later)
- ✅ No vendor lock-in
- ✅ Minimal DevOps complexity
- ✅ Scales if POC succeeds
- ✅ Industry-standard stack

**Limitations:**
- Supabase: 500MB storage (sufficient for POC)
- Supabase: 2 concurrent connections (ok for demo)
- SendGrid: 100 emails/day (enough for testing)
- Vercel: 12s function timeout (sufficient for this POC)

**Best for:** Exploring technologies without budget constraints

---

### Option 2: AWS FREE TIER (12 months)

**If you prefer AWS and want full AWS ecosystem:**
- **Hosting:** AWS EC2 t3.micro (1 year free)
- **Database:** AWS RDS PostgreSQL (1 year free, 20GB)
- **Compute:** Lambda functions (1M/month free)
- **Authentication:** AWS Cognito (free tier)
- **Secrets:** AWS Secrets Manager ($1–2/month)
- **WAF:** AWS WAF ($5–10/month)
- **Monitoring:** CloudWatch ($5–10/month)

**Total estimated cost:** **$0 Year 1 / $40–70/month Year 2+**

**Why choose AWS free tier:**
- ✅ 12 months completely free
- ✅ More powerful than Vercel/Supabase free tiers
- ✅ Handles more concurrent users
- ✅ Learn AWS ecosystem
- ✅ Can scale on AWS indefinitely

**Limitations:**
- Auto-renewal after 12 months (must plan migration)
- More complex setup
- Stricter free tier enforcement

**Best for:** Longer POC or planning AWS-only future

---

### Option 3: Google Cloud FREE TIER

**Generous free tier, no expiration:**
- **Hosting:** Cloud Run (2M requests/month free)
- **Database:** Cloud SQL (db.f1-micro free)
- **Compute:** Cloud Functions (2M invocations/month free)
- **Authentication:** Google Identity (included)

**Total estimated cost:** **$0–5/month** (mostly free)

**Why choose GCP:**
- ✅ Very generous free tier
- ✅ No time limit (unlike AWS)
- ✅ Good for containerized apps
- ✅ Excellent data processing

**Best for:** Long-term free operations without time limit

---

### Option 4: Azure FREE TIER

**Limited free tier:**
- **Hosting:** App Service (limited compute, free)
- **Database:** Azure SQL Database ($5–20/month after 1 month)
- **Storage:** Azure Storage (5GB free)

**Total estimated cost:** **$0–20/month after 1 month**

**Not recommended for POC** (database isn't truly free long-term)

---

## FINAL RECOMMENDATION FOR POC

| Need | Recommendation | Cost | Notes |
|------|---|---|---|
| **Zero-cost, cloud-agnostic** | **Vercel + Supabase (Free)** | **$0** | ⭐ Best choice |
| **AWS learning + 12mo free** | AWS Free Tier | $0–70/month | Good if AWS path |
| **Generous long-term free** | Google Cloud | $0–5/month | No time limit |
| **Simplest setup** | Vercel (free tier) | $0 | Next.js optimized |

---

## Suggested Implementation Path

### Phase 1: Evaluate (Week 0)
1. Create free accounts: Vercel, Supabase
2. Deploy "Hello World" Next.js to Vercel (5 minutes)
3. Connect Supabase database (5 minutes)
4. Test API routes (5 minutes)

**Total time: 15 minutes**
**Total cost: $0**
**Decision: This is clearly the fastest path**

### Phase 2: Build POC (Weeks 1–4)
- Use free-tier stack (Vercel + Supabase)
- Build 3 stories
- Minimal infrastructure management
- Focus on features, not DevOps

**Cost: $0/month**

### Phase 3: Demo & Feedback (Week 5)
- Demonstrate to stakeholders
- Collect feedback
- Cost: $0

### Phase 4: Scale (Month 2+, if approved)
**Choose based on learnings:**
- **Option A:** Stay on Vercel + Supabase (upgrade tiers, ~$50/month)
- **Option B:** Move to AWS (if AWS expertise needed, ~$40–100/month)
- **Option C:** Move to Azure/GCP (if org preference, ~$50–150/month)

**No rework needed** - code is cloud-agnostic

---

## Architecture Summary (Free-Tier POC)

```
┌─────────────────────────────────────────────────────┐
│            GitHub (Free - Code Repo)                │
└──────────────────┬──────────────────────────────────┘
                   │ git push
                   v
┌─────────────────────────────────────────────────────┐
│ Vercel (Free - Auto Deploy Next.js)                 │
│ ├─ Frontend (React)                                 │
│ ├─ API Routes (serverless backend)                  │
│ ├─ Auto HTTPS/TLS 1.3                               │
│ ├─ Built-in DDoS protection                         │
│ └─ Environment secrets management                   │
└──────────────┬──────────────────┬────────────────────┘
               │                  │
               v                  v
    ┌─────────────────┐  ┌──────────────────────┐
    │ Supabase        │  │ SendGrid (Free)      │
    │ (Free)          │  │ ├─ 100 emails/day    │
    │ ├─ PostgreSQL   │  │ └─ No cost           │
    │ ├─ Auth         │  │                      │
    │ ├─ 500MB DB     │  │ Stripe (Free)        │
    │ └─ RLS/RealTime │  │ ├─ Test mode         │
    └─────────────────┘  │ └─ No cost           │
                         └──────────────────────┘
```

---

## Recommendation: START WITH FREE TIER

**Use Vercel + Supabase for the POC.**

**Why:**
1. **$0 cost** - No budget needed
2. **5 minutes setup** - Start building immediately
3. **Industry standard** - Used by real startups
4. **Future-proof** - Scales if successful
5. **Cloud-agnostic** - Move anywhere later
6. **Learn fast** - Less infrastructure, more features

**If it works: Scale later**
**If it doesn't: Zero sunk cost**

This is the **lowest-risk, fastest path** to a working POC.

