# MVP / POC User Story Recommendation v1.0

Prepared by: Business Analysis Support  
Date: 2026-04-09

---

## Purpose
This document proposes a **minimum but viable, cross-cutting** set of user stories for an insurance application POC.

The intent is to help the `Project Manager` and `Architect` choose a scope that is:
- small enough to implement quickly
- realistic enough to demonstrate business value
- broad enough to validate the key architecture decisions
- cross-cutting enough to exercise major platform capabilities

---

## POC Scope Principle
For this POC, the recommended scope should prove these core capabilities:
1. identity and access
2. customer self-service journey
3. assisted sales journey
4. quote-to-policy flow
5. payment integration
6. document generation/access
7. claim initiation
8. workflow/status visibility

This is enough to test the main business and technical seams without attempting full enterprise coverage.

---

## Recommended User Stories for MVP / POC

### 1. CUST-001 - Register for a customer portal account
**Why include it**
- Establishes the external user entry point.
- Validates customer identity creation, consent capture, and account provisioning.
- Needed before any meaningful self-service journey can be demonstrated.

**Architecture value**
- Authentication and identity integration
- Customer profile creation
- Notification integration for verification

---

### 2. CUST-002 - Sign in securely to the customer portal
**Why include it**
- Essential for all customer-authenticated scenarios.
- Demonstrates secure access, session handling, and auditability.
- Required for later policy, payment, and claims features.

**Architecture value**
- Authentication flow
- Session/token handling
- Security logging

---

### 3. CUST-003 - Browse and compare insurance products
**Why include it**
- Gives the POC a visible and business-friendly customer experience.
- Helps validate product configuration, content management, and legal/regulatory messaging.
- Necessary before quote and purchase.

**Architecture value**
- Product catalog integration
- Content and rules management
- Front-end composition for customer journeys

---

### 4. CUST-004 - Request an insurance quote
**Why include it**
- This is the first real business transaction in the customer journey.
- Demonstrates rating logic, product rules, and eligibility evaluation.
- Strong value for PM demo and architect validation.

**Architecture value**
- Quote/rating engine
- Product rule orchestration
- Business validation layer

---

### 5. CUST-005 - Purchase an insurance policy online
**Why include it**
- Converts the quote into real business value.
- Creates the end-to-end commercial flow from discovery to issuance.
- Allows the POC to demonstrate policy issuance, not only inquiry.

**Architecture value**
- Transaction orchestration
- Policy administration integration
- Audit trail and customer declarations

---

### 6. CUST-006 - Make premium payments online
**Why include it**
- Makes the POC financially meaningful.
- Proves payment gateway integration and status reconciliation.
- A practical cross-cutting capability touching billing, policy, and customer communications.

**Architecture value**
- Payment gateway integration
- Billing update and reconciliation
- Receipt generation and notifications

---

### 7. CUST-008 - Download policy documents and certificates
**Why include it**
- Demonstrates document generation and retrieval.
- Important for customer confidence and real-world usability.
- Lightweight but highly visible in a demo.

**Architecture value**
- Document service integration
- Secure retrieval and access control
- Issuance artifact management

---

### 8. CUST-011 - Submit an insurance claim online
**Why include it**
- Shows that the platform supports not only sales, but also post-sales servicing.
- Claims is one of the strongest business scenarios in insurance.
- Gives the POC credibility as an insurance solution, not just an e-commerce portal.

**Architecture value**
- Claims intake workflow
- File/document upload
- Policy-to-claims linkage

---

### 9. CUST-012 - Track claim status and next actions
**Why include it**
- Adds customer transparency and a closed service loop.
- Demonstrates status workflow, milestone tracking, and event-driven updates.
- Strong for customer experience validation.

**Architecture value**
- Workflow state model
- Timeline/status APIs
- Notification/event integration

---

### 10. AGENT-003 - Capture prospect details in the field
**Why include it**
- Introduces an internal-assisted sales channel with minimal extra scope.
- Helps validate multi-persona support beyond the customer portal.
- Useful to prove that customer acquisition can start from field operations.

**Architecture value**
- Shared customer/lead domain
- Mobile/web agent workflow
- Duplicate detection and lead creation

---

### 11. AGENT-004 - Generate quote for a prospect
**Why include it**
- Reuses the quote capability for another channel.
- Demonstrates that the same core business services can support multiple personas.
- Strong validation point for service reuse and domain architecture.

**Architecture value**
- Channel reuse of quote engine
- Shared product/rules services
- Role-based user experience

---

### 12. AGENT-009 - Track application and policy issuance status
**Why include it**
- Gives internal users visibility after sales submission.
- Demonstrates workflow transparency for both external and assisted channels.
- Useful for PM because it shows operational follow-through.

**Architecture value**
- Workflow/status service reuse
- Internal user dashboard patterns
- Cross-channel process visibility

---

## Recommended POC Story Set Summary
If the goal is a **very fast demonstration**, the scope should be reduced to **3 to 4 stories only**.

## Ultra-Minimal Demo Scope (Recommended)

### Option A - Best 3-story demo
1. `CUST-001` Register account  
2. `CUST-004` Request quote  
3. `CUST-005` Purchase policy online  

**Why this works**
- Shows customer onboarding.
- Shows the core insurance transaction.
- Shows conversion from interest to actual policy creation.
- Keeps the demo short and easy to explain.

### Option B - Best 4-story demo
1. `CUST-001` Register account  
2. `CUST-003` Browse products  
3. `CUST-004` Request quote  
4. `CUST-005` Purchase policy online  

**Why this works**
- Tells a complete customer story from discovery to purchase.
- Gives the PM a business-friendly walkthrough.
- Gives the architect enough to validate identity, product, quote, and policy services.
- Still small enough for a quick POC build and demo.

## Recommended Choice
For the best balance of **speed** and **business credibility**, I recommend **Option B - 4 stories**.

It demonstrates:
- user onboarding
- product discovery
- quote generation
- policy purchase

This is the smallest scope that still feels like a real insurance journey.

If a broader scope is needed later, use this shortlist:

### Core 8-story POC
1. `CUST-001` Register account  
2. `CUST-002` Sign in  
3. `CUST-003` Browse products  
4. `CUST-004` Request quote  
5. `CUST-005` Purchase policy  
6. `CUST-006` Make payment  
7. `CUST-008` Download policy documents  
8. `CUST-011` Submit claim  

### Extended cross-cutting POC
Add these if you want stronger multi-persona validation:
9. `CUST-012` Track claim status  
10. `AGENT-003` Capture prospect  
11. `AGENT-004` Generate quote  
12. `AGENT-009` Track issuance status  

---

## Why this is the right POC balance
This recommended set is small but effective because it covers:

### Business coverage
- onboarding
- sales
- conversion
- payment
- servicing
- claims
- assisted channel

### Technical coverage
- authentication
- role-based access
- product catalog
- rules engine
- workflow orchestration
- payment integration
- document management
- notification integration
- claims workflow
- shared services across channels

### Stakeholder coverage
- PM gets a visible, demo-friendly business journey
- Architect gets reusable services and integration validation
- BA gets traceable end-to-end flows
- QA gets clear acceptance path candidates

---

## Suggested POC Demonstration Flow

### Fast 4-story demo flow
1. Customer registers
2. Customer browses products
3. Customer requests a quote
4. Customer purchases a policy

This is the fastest flow that still feels complete from a business perspective.

### Fast 4-story Sequence Diagram
```text
Customer        Customer Portal        Core Services        Back-end Systems
   |                    |                    |                    |
   |-- Register ------->|-- Create account ->|------------------->|
   |<-- Account ready --|<-------------------|<-------------------|
   |
   |-- Browse products->|-- Get catalog ---->|------------------->|
   |<-- Product list ---|<-------------------|<-------------------|
   |
   |-- Request quote -->|-- Calculate quote->|------------------->|
   |<-- Quote result ---|<-------------------|<-------------------|
   |
   |-- Purchase policy->|-- Create policy -->|------------------->|
   |<-- Confirmation ---|<-------------------|<-------------------|
```

### Extended demo flow if more time is available
1. Customer registers and signs in
2. Customer browses products
3. Customer requests a quote
4. Customer purchases and pays for a policy
5. Customer downloads policy documents
6. Customer submits a claim
7. Customer tracks claim status
8. Field agent captures a new prospect and generates a quote
9. Field agent tracks application/policy status

This gives both **customer self-service** and **assisted sales/service** visibility in one POC.

---

## POC End-to-End Sequence Diagram
```text
Customer        Customer Portal     Core Business Services     External/Back-end Systems     Field Agent Portal
   |                    |                     |                           |                          |
   |-- Register ------->|                     |                           |                          |
   |                    |-- Create profile -->|-- Notify/verify --------->|                          |
   |<-- Account ready --|                     |<--------------------------|                          |
   |
   |-- Sign in -------->|-- Authenticate ---->|-- Security check -------->|                          |
   |<-- Access granted -|<--------------------|<--------------------------|                          |
   |
   |-- Browse products->|-- Get catalog ------>|-- Read products --------->|                          |
   |<-- Product list ---|<---------------------|<--------------------------|                          |
   |
   |-- Request quote -->|-- Quote request ---->|-- Apply rating/rules ---->|                          |
   |<-- Quote result ---|<---------------------|<--------------------------|                          |
   |
   |-- Purchase policy->|-- Create purchase -->|-- Issue policy ---------->|                          |
   |-- Pay premium ---->|-- Process payment -->|-------------------------->|                          |
   |<-- Confirmation ---|<---------------------|<--------------------------|                          |
   |
   |-- Download docs -->|-- Fetch documents -->|-- Get policy docs ------->|                          |
   |<-- Documents ------|<---------------------|<--------------------------|                          |
   |
   |-- Submit claim --->|-- Create claim ------>|-- Register claim -------->|                          |
   |<-- Claim ref ------|<---------------------|<--------------------------|                          |
   |
   |-- Track claim ---->|-- Get status -------->|-- Read workflow --------->|                          |
   |<-- Status update --|<---------------------|<--------------------------|                          |
   |                                                                                                   |
   |                                                                                                   |-- Capture prospect ->
   |                                                                                                   |-- Request quote ---->
   |                                                                                                   |<-- Quote result -----
   |                                                                                                   |-- Track issuance --->
```

---

## Sequence Diagram Notes
- The diagram intentionally keeps the service layers grouped to remain easy to read.
- It demonstrates both the **customer channel** and the **field agent channel**.
- It shows the architect where service reuse is expected.
- It shows the PM a realistic demo flow without overloading the POC scope.

---

## Recommendation to PM and Architect
For approval discussions, I recommend positioning the POC as:

**"A digital insurance journey proving onboarding, quote, purchase, payment, policy documents, and claims, with light field-agent support to validate cross-channel architecture reuse."**

That statement is simple, credible, and aligned with both business and architecture expectations.
