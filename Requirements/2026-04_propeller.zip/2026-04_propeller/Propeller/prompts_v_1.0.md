# Session Prompts v1.0

Project: Insurance Customer Portal & Sales Platform  
Date: 2026-04-09  
Recorded by: GitHub Copilot

---

## All User Prompts (Chronological Order)

---

### Prompt 1
> How do I refer files from outside this folder?

**Context:** User wanted to understand how to reference files that exist outside the current workspace folder.

---

### Prompt 2
> Show me a template as to how you will write user stories

**Context:** User wanted to see the proposed format before committing to writing all user stories. Template was to be suitable for circulation to PM and Architect for approval.

---

### Prompt 3
> *(Approval of CUST-001)*  
> Approved

**Context:** User reviewed the first customer user story (CUST-001: Register Account) and approved the template format and quality before proceeding with all remaining stories.

---

### Prompt 4
> No need for further approval, write all customer stories quickly

**Context:** User approved the format and instructed to proceed with all 15 customer user stories (CUST-001 through CUST-015) without requiring individual approvals.

---

### Prompt 5
> Write for Field Agent quickly

**Context:** After all customer stories were complete, user requested the same rapid generation approach for field agent user stories (AGENT-001 through AGENT-010).

---

### Prompt 6
> I need to shorten this so that everything can be quickly demonstrated. I am expecting 3-4 important stories only.

**Context:** User anticipated PM/Architect questions about minimal viable POC scope and wanted a focused shortlist of stories that could be demonstrated in a short time window.

---

### Prompt 7
> I want to go by Option A

**Context:** User selected Option A (3-story POC: CUST-001 Register, CUST-004 Request Quote, CUST-005 Purchase Policy) over Option B (4 stories). This became the definitive POC scope.

---

### Prompt 8
> I need now a list of possible technologies for the POC with costs and recommend the best. Prepare a tech_stack_v_1.0.md file.

**Context:** With POC scope confirmed, user requested a comprehensive technology stack analysis covering all components, with pricing, pros/cons, and clear recommendations.

---

### Prompt 9
> I do not see options like MFA, FIDO 2.0 tokens etc. I mean the security stack is entirely missing. Can you consider that?

**Context:** User reviewed tech_stack_v_1.0.md and noticed no security components had been included. Requested a dedicated security section covering MFA, authentication, encryption, WAF, and audit logging.

---

### Prompt 10
> I am not in favor of any specific cloud or against it. I want to explore if a free cloud account can help for the POC.

**Context:** User was uncomfortable with the AWS-centric recommendation and wanted a cloud-agnostic evaluation with free-tier options presented as primary choices rather than afterthoughts.

---

### Prompt 11
> Summarize the conversation history so far into a condensed format so it can be used as context going forward.

**Context:** As the conversation grew long, user requested a structured summary to preserve key decisions, technical choices, and progress state for future continuation.

---

### Prompt 12
> This is fine. Give me now a high level architecture for the entire application and in it have a section called as HLA for POC with appropriate diagrams. Consider the technology recommendations and a list of tasks for the POC.

**Context:** With technology stack and POC scope both confirmed, user requested a full architectural document combining the complete system architecture, a POC-specific section, ASCII diagrams, data models, deployment flow, and a detailed implementation task list.

---

### Prompt 13
> List all the prompts in this session into a file named prompts_v_1.0.md

**Context:** User requested this file — a chronological record of all prompts from the session.

---

## Files Created During This Session

| File | Description |
|------|-------------|
| user_story_template.md | Reusable template for all user categories |
| customer_user_stories.md | CUST-001 through CUST-015 (15 stories) |
| field_agent_user_stories.md | AGENT-001 through AGENT-010 (10 stories) |
| mvp_poc_v_1.0.md | POC scope: Option A (CUST-001, CUST-004, CUST-005) |
| tech_stack_v_1.0.md | Full technology stack with costs and free-tier recommendations |
| architecture_hla_v_1.0.md | High-level architecture + HLA for POC + task list |
| prompts_v_1.0.md | This file |

---

## Key Decisions Captured

| # | Decision | Outcome |
|---|----------|---------|
| 1 | POC Scope | Option A: 3 stories (CUST-001, CUST-004, CUST-005) |
| 2 | Cloud Platform | Cloud-agnostic; Vercel + Supabase (free tier, $0/month) as primary |
| 3 | Frontend/Backend | Next.js 13+ with TypeScript |
| 4 | Database | PostgreSQL via Supabase (free tier) |
| 5 | Authentication | NextAuth.js + Supabase Auth |
| 6 | MFA | FIDO 2.0 (primary), TOTP (backup), Email OTP (fallback) |
| 7 | Payments | Stripe (test mode for POC) |
| 8 | Email | SendGrid (free tier, 100 emails/day) |
| 9 | Security | Enterprise-grade from day 1 (TLS, encryption, WAF, audit logs) |
| 10 | Timeline | 4-week POC build, 87 hours, 4–5 person team |
