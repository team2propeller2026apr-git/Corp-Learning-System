# Customer User Stories

Prepared by: Business Analysis Support  
Date: 2026-04-09

---

## CUST-001 - Register for a customer portal account

**User Category:** Customer  
**Story Title:** Register for a customer portal account  
**Module / Journey:** Onboarding and Account Access  
**Priority:** High  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** register for an online account  
**So that** I can access insurance products, manage my policies, and track service requests digitally.

### Business Context
- Customers need a self-service web entry point.
- Registration is the foundation for later journeys such as quote requests, policy purchase, claims, and document access.
- This reduces manual support dependency and improves customer experience.

### Preconditions
- Customer has access to the web portal.
- Customer provides required identity and contact details.
- Customer accepts terms and privacy consent.

### Acceptance Criteria
1. Given a new customer is on the registration page, when valid personal and contact details are submitted, then the system creates a new customer portal account.
2. Given the registration form is incomplete or invalid, when the customer submits the form, then the system displays clear validation messages and does not create the account.
3. Given registration is successful, when the account is created, then the customer receives a confirmation message and is prompted to verify email or mobile number.
4. Given an account already exists for the same email or mobile number, when the customer attempts registration, then the system informs the customer and suggests sign-in or password reset.

### Business Rules
- Email address and/or mobile number must be unique per customer portal account.
- Mandatory fields must include name, contact details, and consent acknowledgment.
- Account activation should require verification of at least one contact channel.
- Password policy must comply with company security standards.

### Data Requirements
- Inputs: first name, last name, email, mobile number, password, consent flag
- Validations: required fields, format validation, duplicate account check, password strength
- Outputs: account ID, registration status, verification request
- Notifications: email or SMS verification message

### Exceptions / Edge Cases
- Duplicate email or mobile number
- Weak password
- Verification service unavailable
- Customer session timeout during registration

### Dependencies
- Customer portal UI
- Identity / authentication service
- Customer profile data store
- Email/SMS notification service

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Auth Service        Customer DB        Notification Service
   |                |                  |                  |                      |
   |-- Open form -->|                  |                  |                      |
   |-- Submit data->|                  |                  |                      |
   |                |-- Validate ----->|                  |                      |
   |                |                  |-- Check/Create -->|                      |
   |                |                  |<-- Account OK ----|                      |
   |                |                  |-- Send verify ------------------------->|
   |                |                  |<----------- queued/sent ----------------|
   |                |<-- Success ------|                  |                      |
   |<-- Confirmation|                  |                  |                      |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-002 - Sign in securely to the customer portal

**User Category:** Customer  
**Story Title:** Sign in securely to the customer portal  
**Module / Journey:** Authentication and Access  
**Priority:** High  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** sign in securely to my account  
**So that** I can access my policies, payments, claims, and personal information.

### Business Context
- Customers need secure ongoing access after registration.
- Login is required for all authenticated self-service journeys.
- The process must balance usability and security.

### Preconditions
- Customer account exists and is active.
- Customer has valid login credentials.
- Required verification steps are completed.

### Acceptance Criteria
1. Given a registered customer is on the sign-in page, when valid credentials are entered, then the system grants access to the customer dashboard.
2. Given invalid credentials are entered, when the customer submits the sign-in form, then the system denies access and displays an appropriate message.
3. Given additional verification is required, when the customer signs in, then the system prompts for the configured verification step before access is granted.
4. Given repeated failed login attempts occur, when the threshold is reached, then the system temporarily locks the account or applies additional security controls.

### Business Rules
- Only active and verified accounts can sign in.
- Failed attempts must be logged for audit and security monitoring.
- Session management must comply with company security standards.
- Password reset must be available from the sign-in journey.

### Data Requirements
- Inputs: username/email/mobile, password, verification code if applicable
- Validations: credential match, account status, verification status
- Outputs: authenticated session, access token/session ID, login status
- Notifications: optional suspicious login alert

### Exceptions / Edge Cases
- Forgotten password
- Account locked after repeated failures
- Verification code expired
- Authentication service unavailable

### Dependencies
- Customer portal UI
- Identity / authentication service
- Session management component
- Audit and security logging service

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Auth Service        Security Log
   |                |                  |                  |
   |-- Enter creds->|                  |                  |
   |                |-- Authenticate ->|                  |
   |                |                  |-- Log event ---->|
   |                |                  |<-- Logged -------|
   |                |<-- Success/Fail -|                  |
   |<-- Access msg -|                  |                  |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-003 - Browse and compare insurance products

**User Category:** Customer  
**Story Title:** Browse and compare insurance products  
**Module / Journey:** Product Discovery  
**Priority:** High  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** browse and compare available insurance products  
**So that** I can understand the options and choose the product that best fits my needs.

### Business Context
- Customers need product clarity before requesting a quote or purchasing.
- Product comparison reduces confusion and improves conversion.
- The portal should support informed self-service decision-making.

### Preconditions
- Product catalog is available in the portal.
- Product information is published and approved.
- Customer can access the public or logged-in product pages.

### Acceptance Criteria
1. Given the customer opens the product area, when products are available, then the system displays product categories and summary details.
2. Given the customer selects multiple products, when comparison is requested, then the system shows key benefits, exclusions, eligibility, and pricing indicators side by side.
3. Given a product is selected, when the customer views details, then the system shows coverage, exclusions, documents, and next steps.
4. Given a product is unavailable for the customer's profile or geography, when the customer attempts to proceed, then the system informs the customer accordingly.

### Business Rules
- Only approved and active products can be shown.
- Product content must use the latest approved version.
- Comparison fields must be consistent across comparable products.
- Legal disclaimers must be displayed where required.

### Data Requirements
- Inputs: selected product category, filters, comparison selections
- Validations: product availability, region eligibility, channel eligibility
- Outputs: product list, comparison results, product detail view
- Notifications: none mandatory

### Exceptions / Edge Cases
- Product temporarily unavailable
- Comparison requested with insufficient selections
- Region-specific restrictions
- Product content missing required disclaimers

### Dependencies
- Customer portal UI
- Product catalog service
- Product content repository
- Regulatory/legal content approval source

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Product Service        Content Store
   |                |                  |                    |
   |-- Browse ----->|                  |                    |
   |                |-- Get products ->|                    |
   |                |                  |-- Read content --->|
   |                |                  |<-- Product data ---|
   |                |<-- Product list -|                    |
   |<-- View/Compare|                  |                    |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-004 - Request an insurance quote

**User Category:** Customer  
**Story Title:** Request an insurance quote  
**Module / Journey:** Quote Generation  
**Priority:** High  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** request a quote for an insurance product  
**So that** I can understand the estimated premium and coverage before purchase.

### Business Context
- Quote generation is a core pre-sales journey.
- It enables customers to evaluate affordability and coverage fit.
- It reduces the need for manual intervention in standard cases.

### Preconditions
- Customer has selected a valid insurance product.
- Required quote inputs are known.
- Rating rules are configured in the system.

### Acceptance Criteria
1. Given a customer provides the required quote information, when the quote is submitted, then the system calculates and displays a quote estimate.
2. Given mandatory information is missing or invalid, when the quote is submitted, then the system displays validation messages and does not proceed.
3. Given underwriting or eligibility checks fail, when the quote is processed, then the system displays an appropriate next step or decline message.
4. Given a quote is generated successfully, when the customer chooses to continue, then the system allows progression toward purchase.

### Business Rules
- Quote validity period must be defined.
- Rating logic must follow approved product and underwriting rules.
- Quote outputs must include key assumptions and disclaimers.
- Certain products may require referral rather than instant quoting.

### Data Requirements
- Inputs: personal details, insured item/risk details, coverage selection, geography, optional add-ons
- Validations: completeness, format, eligibility, product rules
- Outputs: quote number, premium estimate, coverage summary, validity period
- Notifications: optional quote email

### Exceptions / Edge Cases
- Ineligible risk profile
- Rating engine unavailable
- Missing product configuration
- Quote expires before purchase

### Dependencies
- Customer portal UI
- Quote/rating engine
- Product rules repository
- Underwriting decision rules

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Quote Engine        Rules Repository
   |                |                 |                    |
   |-- Enter risk ->|                 |                    |
   |                |-- Request quote>|                    |
   |                |                 |-- Read rules ----->|
   |                |                 |<-- Rules ----------|
   |                |<-- Quote result-|                    |
   |<-- View quote -|                 |                    |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-005 - Purchase an insurance policy online

**User Category:** Customer  
**Story Title:** Purchase an insurance policy online  
**Module / Journey:** Policy Purchase  
**Priority:** High  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** purchase a selected insurance policy online  
**So that** I can get insured without visiting a branch or calling support.

### Business Context
- Online purchase is the primary conversion journey for the customer portal.
- Customers expect a guided, digital checkout process.
- The journey should be compliant, traceable, and simple.

### Preconditions
- Customer has a valid quote or selected product configuration.
- Required customer and insured details are available.
- Terms, declarations, and consents can be captured digitally.

### Acceptance Criteria
1. Given a valid quote exists, when the customer confirms details and accepts terms, then the system creates a pending policy purchase transaction.
2. Given payment is successful, when the purchase completes, then the system issues the policy and displays confirmation.
3. Given mandatory declarations are not accepted, when the customer attempts to continue, then the system blocks policy issuance.
4. Given purchase processing fails, when the customer completes checkout, then the system shows a clear failure message and preserves recoverable progress where possible.

### Business Rules
- Policy issuance can occur only after mandatory declarations and payment success.
- Policy effective dates must comply with product rules.
- The final premium must match the approved quote or be recalculated according to rules.
- Audit evidence must be retained for declarations and consents.

### Data Requirements
- Inputs: quote reference, customer data, insured data, declarations, consent, payment choice
- Validations: quote validity, eligibility, mandatory declarations, payment readiness
- Outputs: policy number, purchase confirmation, effective dates
- Notifications: purchase confirmation email/SMS

### Exceptions / Edge Cases
- Quote expired before checkout
- Payment authorized but issuance fails
- Customer exits before completion
- Mandatory document not accepted

### Dependencies
- Customer portal UI
- Quote service
- Policy administration service
- Payment service
- Notification service

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Policy Service        Payment Service
   |                |                  |                    |
   |-- Confirm ---->|                  |                    |
   |                |-- Create order ->|                    |
   |                |-- Pay -------------------------------->|
   |                |<---------------- Payment result -------|
   |                |-- Issue policy ->|                    |
   |                |<-- Policy no. ---|                    |
   |<-- Confirmation|                  |                    |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-006 - Make premium payments online

**User Category:** Customer  
**Story Title:** Make premium payments online  
**Module / Journey:** Billing and Payments  
**Priority:** High  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** pay my premium online  
**So that** I can keep my policy active without manual payment processing.

### Business Context
- Digital payment reduces collection delays and manual reconciliation.
- Customers expect multiple convenient payment methods.
- Payment visibility improves trust and policy continuity.

### Preconditions
- Customer is authenticated.
- A bill, installment, or outstanding premium exists.
- Payment methods are configured and available.

### Acceptance Criteria
1. Given outstanding premium exists, when the customer opens billing, then the system shows due amount, due date, and available payment methods.
2. Given the customer selects a valid payment method, when the payment is submitted, then the system processes the transaction and updates payment status.
3. Given payment succeeds, when the transaction is completed, then the system provides a receipt and updates the policy billing record.
4. Given payment fails or is cancelled, when the transaction ends, then the system displays the status and allows retry where applicable.

### Business Rules
- Payment amount must match allowed billing rules.
- Payment status must be reconciled with the policy billing system.
- Receipts must be generated for successful payments.
- Partial payments may be restricted depending on product rules.

### Data Requirements
- Inputs: policy/bill reference, payment amount, payment method
- Validations: outstanding balance, method availability, payment authorization
- Outputs: transaction status, receipt, updated billing status
- Notifications: payment receipt and confirmation

### Exceptions / Edge Cases
- Gateway timeout
- Duplicate payment attempt
- Partial payment not allowed
- Policy already lapsed or closed

### Dependencies
- Customer portal UI
- Billing system
- Payment gateway
- Receipt/notification service

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Billing System        Payment Gateway
   |                |                  |                    |
   |-- Pay now ---->|                  |                    |
   |                |-- Get dues ----->|                    |
   |                |<-- Amount -------|                    |
   |                |-- Process payment ------------------->|
   |                |<---------------- Result --------------|
   |                |-- Update bill --->|                    |
   |<-- Receipt ----|                  |                    |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-007 - View policy details and coverage summary

**User Category:** Customer  
**Story Title:** View policy details and coverage summary  
**Module / Journey:** Policy Management  
**Priority:** High  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** view my policy details and coverage summary  
**So that** I can understand what is covered, what is excluded, and my policy status.

### Business Context
- Customers need transparency after purchase.
- Policy self-service reduces routine service calls.
- Coverage visibility helps reduce confusion at claim time.

### Preconditions
- Customer is authenticated.
- One or more policies exist and are linked to the customer account.
- Policy data is available in the portal.

### Acceptance Criteria
1. Given the customer has active or historical policies, when the policy section is opened, then the system lists the relevant policies.
2. Given a policy is selected, when details are requested, then the system displays policy number, status, effective dates, insured parties/items, and coverage summary.
3. Given exclusions or endorsements exist, when the customer views policy details, then the system shows them clearly.
4. Given the policy is inactive, lapsed, or cancelled, when viewed, then the system displays the correct status and relevant dates.

### Business Rules
- Customers can only view policies linked to their identity.
- Displayed content must reflect the latest endorsed policy state.
- Sensitive internal-only policy notes must not be shown.
- Policy status labels must be consistent across the platform.

### Data Requirements
- Inputs: customer account, selected policy
- Validations: account-policy linkage, access control
- Outputs: policy summary, coverage details, exclusions, status
- Notifications: none mandatory

### Exceptions / Edge Cases
- Policy not linked correctly
- Historical policy archived but not retrievable
- Coverage data incomplete
- Access attempted for unauthorized policy

### Dependencies
- Customer portal UI
- Policy administration system
- Document/endorsement repository
- Identity and access control service

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Policy Service        Policy Store
   |                |                  |                   |
   |-- Open policy->|                  |                   |
   |                |-- Get policies ->|                   |
   |                |                  |-- Read data ----->|
   |                |                  |<-- Policy data ---|
   |                |<-- Policy view --|                   |
   |<-- Details ----|                  |                   |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-008 - Download policy documents and certificates

**User Category:** Customer  
**Story Title:** Download policy documents and certificates  
**Module / Journey:** Documents and Records  
**Priority:** High  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** download my policy documents and certificates  
**So that** I can keep official records and use them when needed.

### Business Context
- Customers often need immediate access to policy schedules, receipts, and certificates.
- Self-service document access reduces service overhead.
- It also improves transparency and customer confidence.

### Preconditions
- Customer is authenticated.
- Relevant documents exist for the policy.
- Customer has access rights to the requested document.

### Acceptance Criteria
1. Given documents exist for a policy, when the customer opens the documents area, then the system lists available documents by type and date.
2. Given the customer selects a document, when download is requested, then the system provides the correct file.
3. Given a document is unavailable or superseded, when requested, then the system displays the latest valid document or an appropriate message.
4. Given access is unauthorized, when a document is requested, then the system blocks access and logs the event.

### Business Rules
- Only customer-authorized documents may be downloaded.
- The latest approved version of a document must be shown.
- Download actions should be audit logged for sensitive documents.
- Certain documents may require policy to be active or issued.

### Data Requirements
- Inputs: policy reference, selected document type
- Validations: access rights, document availability, version validity
- Outputs: downloadable file, document metadata
- Notifications: optional download audit alert for sensitive items

### Exceptions / Edge Cases
- Document generation delayed
- Corrupt or missing file
- Expired temporary download link
- Customer requests document for cancelled quote instead of issued policy

### Dependencies
- Customer portal UI
- Document management service
- Policy administration system
- Audit logging service

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Document Service        Document Store
   |                |                  |                      |
   |-- Open docs -->|                  |                      |
   |                |-- List docs ---->|                      |
   |                |<-- Doc list -----|                      |
   |-- Download --->|                  |                      |
   |                |-- Fetch file --->|-- Read file ------->|
   |                |<-- File ---------|<-- File data -------|
   |<-- Document ---|                  |                      |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-009 - Update profile and contact information

**User Category:** Customer  
**Story Title:** Update profile and contact information  
**Module / Journey:** Profile Management  
**Priority:** Medium  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** update my profile and contact information  
**So that** my account and policy communications remain accurate.

### Business Context
- Current customer details are required for servicing, billing, and claims.
- Self-service updates reduce operational workload.
- Some changes may affect compliance or servicing workflows.

### Preconditions
- Customer is authenticated.
- Customer profile exists.
- Editable fields are configured by business rules.

### Acceptance Criteria
1. Given the customer opens profile settings, when editable fields are available, then the system displays current profile details.
2. Given valid updated information is submitted, when the customer saves changes, then the system updates the customer profile and confirms success.
3. Given a field requires verification, when the customer updates it, then the system triggers the required verification flow before finalizing the change.
4. Given a restricted field cannot be changed online, when the customer attempts to modify it, then the system explains the alternate process.

### Business Rules
- Certain identity fields may be read-only after verification.
- Contact changes may require email or mobile verification.
- Profile changes must be time-stamped and audit logged.
- Policy-impacting changes may trigger downstream review.

### Data Requirements
- Inputs: address, email, mobile, communication preferences, other editable profile data
- Validations: format, duplicate checks where applicable, verification rules
- Outputs: updated customer profile, change status
- Notifications: profile update confirmation

### Exceptions / Edge Cases
- Verification not completed
- Restricted field change attempt
- Downstream profile sync failure
- Customer tries to save unchanged data

### Dependencies
- Customer portal UI
- Customer profile service
- Identity verification service
- Notification service

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Profile Service        Verification Service
   |                |                  |                        |
   |-- Edit info -->|                  |                        |
   |                |-- Save changes ->|                        |
   |                |                  |-- Verify change ------>|
   |                |                  |<-- Verified/Needed ----|
   |                |<-- Update result-|                        |
   |<-- Confirmation|                  |                        |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-010 - Renew an existing policy

**User Category:** Customer  
**Story Title:** Renew an existing policy  
**Module / Journey:** Renewals  
**Priority:** High  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** renew my policy online  
**So that** I can maintain continuous coverage without manual intervention.

### Business Context
- Digital renewals support policy retention.
- Customers need a quick way to review and accept renewal terms.
- Renewal flow should highlight changes in coverage or premium.

### Preconditions
- Policy is eligible for renewal.
- Renewal offer has been generated.
- Customer is authenticated and linked to the policy.

### Acceptance Criteria
1. Given a policy is eligible for renewal, when the customer opens the renewal section, then the system displays the renewal offer and due date.
2. Given the customer accepts the renewal offer and pays if required, when renewal is completed, then the system extends coverage and confirms renewal.
3. Given underwriting review is needed, when the customer attempts renewal, then the system displays the required next step.
4. Given the renewal offer has expired, when the customer attempts to proceed, then the system informs the customer and blocks expired renewal processing.

### Business Rules
- Only eligible policies can be renewed online.
- Renewal terms must reflect approved premium and coverage changes.
- Renewal must be completed before cutoff according to business rules.
- Some renewals may require re-declaration or re-underwriting.

### Data Requirements
- Inputs: policy reference, renewal acceptance, updated declarations if required, payment details
- Validations: policy eligibility, renewal offer validity, payment status
- Outputs: renewed policy term, confirmation, updated documents
- Notifications: renewal confirmation and receipt

### Exceptions / Edge Cases
- Policy not eligible for renewal
- Renewal premium changed after offer generation
- Renewal offer expired
- Payment successful but renewal posting delayed

### Dependencies
- Customer portal UI
- Policy administration system
- Renewal calculation service
- Payment service
- Notification/document services

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Renewal Service        Payment Service
   |                |                  |                    |
   |-- Open renewal>|                  |                    |
   |                |-- Get offer ---->|                    |
   |                |<-- Renewal offer-|                    |
   |-- Accept/pay ->|                  |                    |
   |                |-- Process pay ----------------------->|
   |                |<---------------- Result --------------|
   |                |-- Renew policy ->|                    |
   |<-- Confirmation|<-- Renewal done -|                    |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-011 - Submit an insurance claim online

**User Category:** Customer  
**Story Title:** Submit an insurance claim online  
**Module / Journey:** Claims Intake  
**Priority:** High  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** submit a claim online  
**So that** I can report a loss event quickly and start the claims process.

### Business Context
- Claims submission is a critical service journey.
- Customers need a guided and empathetic digital process.
- Early and accurate capture improves downstream claim handling.

### Preconditions
- Customer is authenticated.
- Policy exists and is eligible for claims reporting.
- Required event and supporting information can be captured.

### Acceptance Criteria
1. Given the customer selects an eligible policy, when claim details are entered and submitted, then the system creates a claim record and returns a claim reference.
2. Given mandatory claim information is missing, when the customer submits, then the system shows validation messages and blocks submission.
3. Given supporting documents are required, when the customer submits the claim, then the system prompts for upload immediately or as a follow-up step.
4. Given the reported event falls outside policy coverage or reporting rules, when submitted, then the system displays an appropriate message or routes the claim for review.

### Business Rules
- Claim submission must be linked to an eligible policy.
- Mandatory fields vary by product and claim type.
- Claim submission timestamp must be recorded.
- Some claim types may require immediate escalation or manual review.

### Data Requirements
- Inputs: policy reference, incident date/time, incident description, claim type, loss details, attachments
- Validations: policy eligibility, mandatory fields, date rules, file type/size checks
- Outputs: claim reference, intake status, next steps
- Notifications: claim submission confirmation

### Exceptions / Edge Cases
- Event date outside allowable reporting window
- Policy inactive at incident date
- Attachment upload failure
- Duplicate claim suspected

### Dependencies
- Customer portal UI
- Claims management system
- Policy administration system
- Document upload service
- Notification service

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Claims Service        Document Service
   |                |                  |                    |
   |-- Enter claim->|                  |                    |
   |                |-- Submit claim ->|                    |
   |                |-- Upload docs ----------------------->|
   |                |<---------------- Upload status -------|
   |                |<-- Claim ref -----|                   |
   |<-- Confirmation|                  |                    |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-012 - Track claim status and next actions

**User Category:** Customer  
**Story Title:** Track claim status and next actions  
**Module / Journey:** Claims Tracking  
**Priority:** High  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** track my claim status online  
**So that** I know the progress, pending actions, and expected next steps.

### Business Context
- Claim visibility reduces inbound support requests.
- Customers need transparency during stressful claim events.
- Timely next-action visibility helps avoid delays.

### Preconditions
- Customer is authenticated.
- At least one claim exists and is linked to the customer.
- Claim status data is available for display.

### Acceptance Criteria
1. Given claims exist, when the customer opens the claims section, then the system lists claim references, statuses, and dates.
2. Given a claim is selected, when details are viewed, then the system displays current status, required actions, recent updates, and expected next step.
3. Given additional information is required from the customer, when the claim is viewed, then the system highlights the pending action clearly.
4. Given claim processing reaches a major milestone, when the customer checks status, then the system shows the latest milestone and outcome.

### Business Rules
- Customers can only view claims tied to their own policies.
- Internal-only notes and sensitive investigation content must not be exposed.
- Status labels shown to customers must be business-friendly.
- Updates must reflect the latest claim workflow state.

### Data Requirements
- Inputs: customer account, selected claim reference
- Validations: claim linkage, access rights
- Outputs: claim timeline, status, next actions, milestone view
- Notifications: optional milestone alerts

### Exceptions / Edge Cases
- Claim record exists but status feed delayed
- Claim closed and archived
- Pending action deadline expired
- Unauthorized claim access attempt

### Dependencies
- Customer portal UI
- Claims management system
- Workflow/status service
- Notification service

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Claims Service        Workflow Store
   |                |                  |                    |
   |-- Open claims->|                  |                    |
   |                |-- Get statuses ->|                    |
   |                |                  |-- Read timeline -->|
   |                |                  |<-- Status data ----|
   |                |<-- Claim view ---|                    |
   |<-- Status -----|                  |                    |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-013 - Upload additional documents for servicing or claims

**User Category:** Customer  
**Story Title:** Upload additional documents for servicing or claims  
**Module / Journey:** Customer Servicing  
**Priority:** Medium  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** upload requested supporting documents  
**So that** my purchase, service request, or claim can be processed without delay.

### Business Context
- Many customer journeys require supporting evidence.
- Digital upload reduces branch visits and email-based handling.
- Structured uploads improve operational turnaround time.

### Preconditions
- Customer is authenticated.
- A transaction, service request, or claim requiring documents exists.
- Accepted file rules are defined.

### Acceptance Criteria
1. Given a request for documents exists, when the customer opens the upload area, then the system shows required document types and upload guidance.
2. Given a valid file is selected, when the customer uploads it, then the system stores the file and confirms successful upload.
3. Given an invalid file type or size is selected, when upload is attempted, then the system blocks the upload and shows a clear validation message.
4. Given all mandatory documents are uploaded, when the customer completes the step, then the system marks the requirement as fulfilled.

### Business Rules
- Accepted formats and size limits must be enforced.
- Uploaded documents must be linked to the correct business transaction.
- Sensitive files must be stored securely.
- Replacement uploads should preserve version history where required.

### Data Requirements
- Inputs: file, document type, related transaction reference
- Validations: file type, size, malware/security checks, transaction linkage
- Outputs: upload confirmation, document status, stored document reference
- Notifications: optional confirmation or pending review notice

### Exceptions / Edge Cases
- Upload interrupted by connectivity issue
- Duplicate file uploaded
- Malware/security scan failure
- Wrong document type selected

### Dependencies
- Customer portal UI
- Document upload/storage service
- Claims/service workflow system
- Security scanning capability

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Upload Service        Workflow System
   |                |                  |                    |
   |-- Select file->|                  |                    |
   |                |-- Upload ------->|                    |
   |                |                  |-- Link doc ------->|
   |                |                  |<-- Linked ---------|
   |                |<-- Upload OK ----|                    |
   |<-- Confirmation|                  |                    |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-014 - Raise a customer service request or support inquiry

**User Category:** Customer  
**Story Title:** Raise a customer service request or support inquiry  
**Module / Journey:** Support and Assistance  
**Priority:** Medium  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** raise a service request or support inquiry  
**So that** I can get help for issues not resolved through self-service features.

### Business Context
- Not all needs fit standardized transactions.
- Customers need a fallback support channel within the portal.
- Structured requests improve routing and response time.

### Preconditions
- Customer is authenticated or allowed to contact support through the portal.
- Support categories are defined.
- Routing and ticket handling process exists.

### Acceptance Criteria
1. Given the customer opens support, when service categories are available, then the system allows the customer to select an issue type and submit details.
2. Given required support details are provided, when the request is submitted, then the system creates a service ticket and returns a reference number.
3. Given the issue type maps to a specialist team, when the request is submitted, then the system routes it to the correct queue.
4. Given the submission is incomplete, when the customer attempts to send the request, then the system shows validation messages and prevents submission.

### Business Rules
- Support requests must be categorized for routing.
- Service level expectations should be communicated where applicable.
- Sensitive cases may require restricted handling.
- Ticket creation and updates must be audit tracked.

### Data Requirements
- Inputs: issue category, description, related policy/claim reference, attachments if needed
- Validations: mandatory fields, category mapping, reference validity
- Outputs: ticket reference, routing status, expected response guidance
- Notifications: request acknowledgment and ticket updates

### Exceptions / Edge Cases
- Wrong category selected
- Ticket routing rule missing
- Attachment upload failure during request creation
- Duplicate service request submitted

### Dependencies
- Customer portal UI
- CRM/service desk system
- Routing rules engine
- Notification service

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Service Desk        Routing Engine
   |                |                  |                  |
   |-- Submit issue>|                  |                  |
   |                |-- Create ticket->|                  |
   |                |                  |-- Route -------->|
   |                |                  |<-- Queue --------|
   |                |<-- Ticket ref ---|                  |
   |<-- Acknowledged|                  |                  |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA

---

## CUST-015 - Manage notification preferences

**User Category:** Customer  
**Story Title:** Manage notification preferences  
**Module / Journey:** Communication Preferences  
**Priority:** Medium  
**Channel:** Web  
**Release / Phase:** Phase 1

### User Story
**As a** Customer  
**I want to** manage how I receive policy and service notifications  
**So that** I get relevant updates through my preferred communication channels.

### Business Context
- Customers expect control over communication channels.
- Preference management improves engagement and compliance.
- It helps reduce missed reminders and unnecessary communications.

### Preconditions
- Customer is authenticated.
- Notification channels and consent settings are configured.
- Customer profile exists.

### Acceptance Criteria
1. Given the customer opens communication preferences, when existing settings are available, then the system displays current notification options.
2. Given the customer updates preferences, when changes are saved, then the system stores the new settings successfully.
3. Given a selected communication method requires verification or consent, when the customer enables it, then the system enforces the required rule.
4. Given mandatory regulatory or service notifications cannot be disabled, when the customer attempts to disable them, then the system prevents the change and explains why.

### Business Rules
- Mandatory service or regulatory communications cannot be fully opted out.
- Marketing preferences must comply with consent rules.
- Preference changes must be audit logged.
- Preferences should apply across supported customer communications.

### Data Requirements
- Inputs: channel preferences, consent selections
- Validations: verified channel, consent eligibility, mandatory notification rules
- Outputs: updated preference profile, confirmation status
- Notifications: confirmation of preference change

### Exceptions / Edge Cases
- Customer disables all optional channels
- Verification required for new communication channel
- Downstream notification system sync failure
- Conflict between consent and mandatory notice rules

### Dependencies
- Customer portal UI
- Customer profile service
- Notification preference service
- Compliance/consent rules service

### Simple ASCII Sequence Diagram
```text
Customer        Web Portal        Preference Service        Notification System
   |                |                    |                         |
   |-- Change prefs>|                    |                         |
   |                |-- Save prefs ----->|                         |
   |                |                    |-- Sync settings ------->|
   |                |                    |<-- Sync result ---------|
   |                |<-- Saved ----------|                         |
   |<-- Confirmation|                    |                         |
```

### Definition of Done
- Acceptance criteria reviewed and approved
- Business rules confirmed
- Dependencies identified
- Edge cases documented
- Sequence diagram included
- Ready for design, development, and QA
