# Field Agent User Stories

Prepared by: Business Analysis Support  
Date: 2026-04-09

---

## AGENT-001 - Sign in to the field agent portal

**User Category:** Field Agent  
**Story Title:** Sign in to the field agent portal  
**Module / Journey:** Authentication and Access  
**Priority:** High  
**Channel:** Web / Mobile  
**Release / Phase:** Phase 1

### User Story
**As a** Field Agent  
**I want to** sign in securely to the field agent portal  
**So that** I can perform sales and service activities assigned to me.

### Business Context
- Field agents need secure access to customer and sales journeys.
- Access should support work from branch, field, and mobile environments.
- Authentication is the entry point for all agent activity.

### Preconditions
- Agent account exists and is active.
- Agent has valid credentials.
- Required device or channel access is enabled.

### Acceptance Criteria
1. Given an active field agent account, when valid credentials are entered, then the system grants access to the agent dashboard.
2. Given invalid credentials are entered, when sign-in is attempted, then the system denies access and shows an appropriate message.
3. Given additional verification is required, when the agent signs in, then the system prompts for the configured verification step.
4. Given repeated failed attempts occur, when the threshold is reached, then the system applies account protection controls.

### Business Rules
- Only active agents can sign in.
- Login attempts must be audit logged.
- Session controls must meet company security policy.
- Unauthorized customer access must be prevented.

### Dependencies
- Agent portal UI
- Identity service
- Security logging service

### Simple ASCII Sequence Diagram
```text
Field Agent     Agent Portal       Auth Service       Security Log
    |                |                  |                  |
    |-- Sign in ---->|                  |                  |
    |                |-- Authenticate ->|                  |
    |                |                  |-- Log event ---->|
    |                |<-- Result -------|                  |
    |<-- Dashboard --|                  |                  |
```

---

## AGENT-002 - View assigned leads and prospects

**User Category:** Field Agent  
**Story Title:** View assigned leads and prospects  
**Module / Journey:** Lead Management  
**Priority:** High  
**Channel:** Web / Mobile  
**Release / Phase:** Phase 1

### User Story
**As a** Field Agent  
**I want to** view leads assigned to me  
**So that** I can follow up with prospects and convert opportunities.

### Business Context
- Lead visibility is core to field sales execution.
- Agents need prioritized prospects and status tracking.
- Assignment clarity improves accountability and conversion.

### Preconditions
- Agent is authenticated.
- Leads are assigned in the CRM or lead system.
- Agent territory or assignment rules are configured.

### Acceptance Criteria
1. Given assigned leads exist, when the agent opens the lead dashboard, then the system lists assigned leads with status and priority.
2. Given a lead is selected, when details are opened, then the system shows contact details, product interest, and next action.
3. Given no leads are assigned, when the agent opens the dashboard, then the system shows an empty state.
4. Given assignment rules change, when lead data refreshes, then the updated lead ownership is shown.

### Business Rules
- Agents can view only assigned or permitted leads.
- Lead priority must follow business-defined scoring.
- Sensitive prospect data must be masked where required.
- All lead views should be traceable for audit.

### Dependencies
- Agent portal UI
- CRM / lead management system
- Assignment rules engine

### Simple ASCII Sequence Diagram
```text
Field Agent     Agent Portal       Lead Service        CRM Store
    |                |                  |                 |
    |-- Open leads -->|                 |                 |
    |                |-- Get leads ---->|                 |
    |                |                  |-- Read leads -->|
    |                |<-- Lead list ----|                 |
    |<-- View leads -|                  |                 |
```

---

## AGENT-003 - Capture prospect details in the field

**User Category:** Field Agent  
**Story Title:** Capture prospect details in the field  
**Module / Journey:** Lead Creation  
**Priority:** High  
**Channel:** Mobile / Web  
**Release / Phase:** Phase 1

### User Story
**As a** Field Agent  
**I want to** capture prospect details during meetings  
**So that** I can create leads immediately and reduce follow-up delays.

### Business Context
- Agents often meet prospects outside the office.
- Fast lead capture reduces data loss and speeds follow-up.
- Standardized capture improves data quality.

### Preconditions
- Agent is authenticated.
- Lead capture form is available.
- Required fields and consent rules are defined.

### Acceptance Criteria
1. Given the agent opens lead capture, when valid prospect data is entered, then the system creates a new lead.
2. Given mandatory fields are missing, when the form is submitted, then the system blocks submission and shows validation errors.
3. Given consent is required, when contact details are captured, then the system records consent status.
4. Given duplicate prospect details are detected, when submission occurs, then the system alerts the agent and suggests existing records.

### Business Rules
- Mandatory lead fields must be enforced.
- Duplicate checks must run on key identifiers.
- Consent capture must comply with communication rules.
- Lead ownership should default to the creating field agent unless reassigned.

### Dependencies
- Agent portal UI
- CRM / lead system
- Duplicate detection service

### Simple ASCII Sequence Diagram
```text
Field Agent     Agent Portal       Lead Service        Duplicate Check
    |                |                  |                   |
    |-- Enter lead ->|                  |                   |
    |                |-- Submit lead -->|                   |
    |                |                  |-- Check dup ----->|
    |                |                  |<-- Result --------|
    |                |<-- Lead created -|                   |
    |<-- Confirmation|                  |                   |
```

---

## AGENT-004 - Generate quote for a prospect

**User Category:** Field Agent  
**Story Title:** Generate quote for a prospect  
**Module / Journey:** Quote Support  
**Priority:** High  
**Channel:** Web / Mobile  
**Release / Phase:** Phase 1

### User Story
**As a** Field Agent  
**I want to** generate a quote for a prospect  
**So that** I can provide pricing and coverage options during or after engagement.

### Business Context
- Agents need quick quoting to support conversion.
- Guided quotes reduce dependency on back-office teams.
- Standard quotes should be generated consistently.

### Preconditions
- Agent is authenticated.
- Prospect or customer record exists.
- Product rules and rating setup are available.

### Acceptance Criteria
1. Given required quote information is entered, when the agent submits the request, then the system generates a quote.
2. Given information is incomplete or invalid, when the quote is requested, then the system blocks processing and shows errors.
3. Given underwriting referral is required, when the quote is processed, then the system marks the quote for referral.
4. Given quote generation succeeds, when results are displayed, then the agent can share or continue to application.

### Business Rules
- Quotes must use current product rules.
- Agent-generated quotes must be linked to the agent record.
- Referral thresholds must be enforced.
- Quote validity period must be shown.

### Dependencies
- Agent portal UI
- Quote engine
- Product rules repository
- Underwriting rules service

### Simple ASCII Sequence Diagram
```text
Field Agent     Agent Portal       Quote Engine        Rules Repository
    |                |                 |                    |
    |-- Request ---->|                 |                    |
    |                |-- Get quote --->|                    |
    |                |                 |-- Read rules ----->|
    |                |<-- Quote -------|                    |
    |<-- View quote -|                 |                    |
```

---

## AGENT-005 - Submit policy application on behalf of a customer

**User Category:** Field Agent  
**Story Title:** Submit policy application on behalf of a customer  
**Module / Journey:** Sales Conversion  
**Priority:** High  
**Channel:** Web / Mobile  
**Release / Phase:** Phase 1

### User Story
**As a** Field Agent  
**I want to** submit a policy application for a customer  
**So that** I can convert an opportunity into business during the sales cycle.

### Business Context
- Field agents often assist customers with application completion.
- Guided submission improves completeness and conversion.
- Agent-assisted journeys must remain compliant and traceable.

### Preconditions
- Customer/prospect and quote exist.
- Required declarations and documents can be captured.
- Agent is authorized to submit the application.

### Acceptance Criteria
1. Given a valid quote exists, when the agent completes the application and submits it, then the system creates an application record.
2. Given mandatory declarations or fields are missing, when submission is attempted, then the system blocks submission.
3. Given supporting documents are required, when the application is submitted, then the system captures or requests them.
4. Given underwriting review is needed, when the application is processed, then the system routes the application accordingly.

### Business Rules
- Agent-assisted applications must record who submitted them.
- Mandatory declarations cannot be bypassed.
- Product eligibility and underwriting rules must apply.
- Supporting documents must be linked to the application.

### Dependencies
- Agent portal UI
- Application processing service
- Underwriting workflow
- Document service

### Simple ASCII Sequence Diagram
```text
Field Agent     Agent Portal       Application Service      Underwriting Queue
    |                |                    |                        |
    |-- Submit app ->|                    |                        |
    |                |-- Create app ----->|                        |
    |                |                    |-- Route if needed ---->|
    |                |<-- App ref --------|                        |
    |<-- Confirmation|                    |                        |
```

---

## AGENT-006 - Upload KYC and supporting documents

**User Category:** Field Agent  
**Story Title:** Upload KYC and supporting documents  
**Module / Journey:** Document Collection  
**Priority:** High  
**Channel:** Mobile / Web  
**Release / Phase:** Phase 1

### User Story
**As a** Field Agent  
**I want to** upload customer KYC and supporting documents  
**So that** applications and service requests can be processed without delay.

### Business Context
- Agents frequently collect documents in customer meetings.
- Central upload reduces email and paper handling.
- Proper document capture improves compliance and turnaround time.

### Preconditions
- Agent is authenticated.
- Related customer/application/claim record exists.
- Allowed document rules are configured.

### Acceptance Criteria
1. Given a related business record exists, when the agent uploads a valid document, then the system stores and links the document correctly.
2. Given an invalid file type or size is selected, when upload is attempted, then the system blocks the upload.
3. Given all required documents are uploaded, when the workflow checks completeness, then the requirement is marked complete.
4. Given upload fails, when the transaction ends, then the system shows an error and allows retry.

### Business Rules
- Document type, format, and size rules must be enforced.
- Uploaded files must be securely stored.
- Agent uploads must be audit logged.
- Mandatory document lists may vary by product or workflow.

### Dependencies
- Agent portal UI
- Document management service
- Workflow service
- Security scanning capability

### Simple ASCII Sequence Diagram
```text
Field Agent     Agent Portal       Document Service       Workflow Service
    |                |                  |                      |
    |-- Upload doc ->|                  |                      |
    |                |-- Store doc ---->|                      |
    |                |                  |-- Link/update ----->|
    |                |<-- Upload OK ----|                      |
    |<-- Confirmation|                  |                      |
```

---

## AGENT-007 - Schedule and track field visits

**User Category:** Field Agent  
**Story Title:** Schedule and track field visits  
**Module / Journey:** Activity Management  
**Priority:** Medium  
**Channel:** Mobile / Web  
**Release / Phase:** Phase 1

### User Story
**As a** Field Agent  
**I want to** schedule and track customer visits  
**So that** I can manage my field activity efficiently and maintain follow-up discipline.

### Business Context
- Field work requires planning and visit tracking.
- Managers need visibility into activity progress.
- Structured visit logging supports productivity analysis.

### Preconditions
- Agent is authenticated.
- Calendar/activity features are enabled.
- Customer or lead records exist.

### Acceptance Criteria
1. Given an assigned lead or customer exists, when the agent schedules a visit, then the system records the planned activity.
2. Given a scheduled visit exists, when the agent updates the outcome, then the system stores visit notes and status.
3. Given a visit is overdue, when the agent or manager reviews activities, then the system flags it accordingly.
4. Given the agent reschedules a visit, when changes are saved, then the updated schedule is reflected.

### Business Rules
- Activities must be linked to a lead or customer.
- Visit outcomes should use standard status values.
- Activity logs must be timestamped.
- Manager visibility depends on reporting hierarchy.

### Dependencies
- Agent portal UI
- Activity/task service
- CRM / customer records

### Simple ASCII Sequence Diagram
```text
Field Agent     Agent Portal       Activity Service       CRM Store
    |                |                  |                    |
    |-- Schedule ---->|                 |                    |
    |                |-- Save visit --->|                    |
    |                |                  |-- Link record ---->|
    |                |<-- Saved --------|                    |
    |<-- Visit plan -|                  |                    |
```

---

## AGENT-008 - Record meeting outcome and next action

**User Category:** Field Agent  
**Story Title:** Record meeting outcome and next action  
**Module / Journey:** Follow-up Management  
**Priority:** High  
**Channel:** Mobile / Web  
**Release / Phase:** Phase 1

### User Story
**As a** Field Agent  
**I want to** record the outcome of a customer interaction  
**So that** follow-up actions are clear and opportunity progress is visible.

### Business Context
- Meeting outcomes drive the next sales or service step.
- Standardized outcome capture improves reporting quality.
- Timely follow-up improves conversion rates.

### Preconditions
- Agent is authenticated.
- A lead, prospect, or customer interaction exists.
- Outcome categories are configured.

### Acceptance Criteria
1. Given a field interaction has occurred, when the agent records the outcome, then the system stores notes, status, and next action.
2. Given a follow-up date is provided, when the record is saved, then the system creates a pending reminder or task.
3. Given the outcome indicates closure or decline, when saved, then the system updates the opportunity status accordingly.
4. Given mandatory notes are missing, when save is attempted, then the system blocks completion.

### Business Rules
- Outcome categories must be standardized.
- Important lead status changes must be audit tracked.
- Next actions should be linked to activity management.
- Closure reasons should be mandatory where applicable.

### Dependencies
- Agent portal UI
- CRM / opportunity service
- Activity/reminder service

### Simple ASCII Sequence Diagram
```text
Field Agent     Agent Portal       Opportunity Service      Reminder Service
    |                |                    |                        |
    |-- Save outcome>|                    |                        |
    |                |-- Update opp. ---->|                        |
    |                |-- Create reminder ------------------------->|
    |                |<-- Saved ----------|                        |
    |<-- Confirmation|                    |                        |
```

---

## AGENT-009 - Track application and policy issuance status

**User Category:** Field Agent  
**Story Title:** Track application and policy issuance status  
**Module / Journey:** Sales Tracking  
**Priority:** High  
**Channel:** Web / Mobile  
**Release / Phase:** Phase 1

### User Story
**As a** Field Agent  
**I want to** track the status of submitted applications and issued policies  
**So that** I can update customers and follow up on pending actions.

### Business Context
- Agents need visibility after submission.
- Status transparency reduces handoff gaps between field and operations.
- It supports proactive customer communication.

### Preconditions
- Agent is authenticated.
- Applications or policies linked to agent activity exist.
- Status workflow data is available.

### Acceptance Criteria
1. Given submitted applications exist, when the agent opens the tracking view, then the system lists status, submission date, and pending items.
2. Given a specific application is selected, when details are viewed, then the system shows stage, blockers, and next action.
3. Given policy issuance is completed, when status refreshes, then the system shows the issued policy reference.
4. Given an application requires additional information, when the agent views it, then the missing requirement is shown clearly.

### Business Rules
- Agents can view only records linked to their permitted book of business.
- Internal-only notes may be restricted.
- Status labels must be understandable to sales users.
- Refresh logic must reflect latest workflow state.

### Dependencies
- Agent portal UI
- Application workflow service
- Policy administration system

### Simple ASCII Sequence Diagram
```text
Field Agent     Agent Portal       Workflow Service       Policy System
    |                |                  |                    |
    |-- Open track -->|                 |                    |
    |                |-- Get statuses ->|                    |
    |                |                  |-- Read policy ---->|
    |                |<-- Statuses -----|                    |
    |<-- View status -|                  |                    |
```

---

## AGENT-010 - View sales performance and commission summary

**User Category:** Field Agent  
**Story Title:** View sales performance and commission summary  
**Module / Journey:** Performance Tracking  
**Priority:** Medium  
**Channel:** Web  
**Release / Phase:** Phase 2

### User Story
**As a** Field Agent  
**I want to** view my sales performance and commission summary  
**So that** I can understand my progress, earnings, and targets.

### Business Context
- Performance visibility motivates agents and reduces manual inquiries.
- Commission transparency improves trust.
- Agents need a simple view of target achievement.

### Preconditions
- Agent is authenticated.
- Sales and commission data is available.
- Reporting period is defined.

### Acceptance Criteria
1. Given performance data exists, when the agent opens the performance view, then the system shows sales volume, conversion, and target progress.
2. Given commission data is available, when the summary is opened, then the system shows earned, pending, and adjusted commission amounts.
3. Given filters are applied, when the period or product changes, then the system refreshes results accordingly.
4. Given commission data is not finalized, when viewed, then the system marks the values as provisional where applicable.

### Business Rules
- Commission visibility depends on business approval and role permissions.
- Performance data should align with official reporting definitions.
- Adjustments and reversals must be reflected clearly.
- Sensitive compensation data must be access-controlled.

### Dependencies
- Agent portal UI
- Sales reporting service
- Commission system

### Simple ASCII Sequence Diagram
```text
Field Agent     Agent Portal       Reporting Service       Commission System
    |                |                  |                        |
    |-- Open perf. -->|                 |                        |
    |                |-- Get metrics -->|                        |
    |                |-- Get commission ----------------------->|
    |                |<---------------- Commission data --------|
    |                |<-- Metrics -------|                       |
    |<-- Dashboard --|                  |                        |
```
