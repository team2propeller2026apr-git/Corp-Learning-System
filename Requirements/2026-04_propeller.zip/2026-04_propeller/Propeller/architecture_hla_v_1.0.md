# High-Level Architecture (HLA) v1.0

Insurance Customer Portal & Sales Platform  
Prepared by: Business Analysis Support  
Date: 2026-04-09

---

## Executive Summary

This document describes the high-level architecture for a cloud-native insurance platform supporting:
- **Customer Portal** (self-service: register, quote, purchase, claims)
- **Field Agent Portal** (assisted sales: lead capture, quote, tracking)
- **Secure, scalable, multi-tenant infrastructure**

**POC Focus:** 3 core user stories (register, quote, purchase) with production-grade security

---

## Part 1: Complete System Architecture

### 1.1 Layered Architecture

```text
┌─────────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                           │
│                                                                  │
│  ┌──────────────────┐              ┌──────────────────┐        │
│  │  Customer Portal │              │  Agent Portal    │        │
│  │   (React/Web)    │              │  (React/Mobile)  │        │
│  └──────────────────┘              └──────────────────┘        │
└─────────────────────────────────────────────────────────────────┘
                               │
                               v
┌─────────────────────────────────────────────────────────────────┐
│                    API GATEWAY LAYER                            │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  • Authentication & Authorization (NextAuth.js)        │   │
│  │  • Rate Limiting (prevent abuse)                       │   │
│  │  • Request Validation & Sanitization                   │   │
│  │  • CORS (Cross-Origin Resource Sharing)                │   │
│  │  • SSL/TLS Termination (HTTPS)                         │   │
│  │  • Request/Response Logging                            │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                               │
                               v
┌─────────────────────────────────────────────────────────────────┐
│                   BUSINESS LOGIC LAYER                          │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────────────┐    │
│  │ Quote Engine │  │ Policy Mgmt  │  │  Claims Service   │    │
│  │              │  │              │  │                   │    │
│  │ • Rating     │  │ • Creation   │  │ • Intake          │    │
│  │ • Rules      │  │ • Issuance   │  │ • Status Track    │    │
│  │ • Validation │  │ • Status     │  │ • Document Mgmt   │    │
│  └──────────────┘  └──────────────┘  └───────────────────┘    │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────────────┐    │
│  │ Auth Service │  │ User Mgmt    │  │ Payment Service   │    │
│  │              │  │              │  │                   │    │
│  │ • MFA (FIDO) │  │ • Profile    │  │ • Process Payment │    │
│  │ • Sessions   │  │ • Preferences│  │ • Reconciliation  │    │
│  │ • Tokens     │  │ • Documents  │  │ • Webhook Handler │    │
│  └──────────────┘  └──────────────┘  └───────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
                               │
                               v
┌─────────────────────────────────────────────────────────────────┐
│                     DATA LAYER                                  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  PostgreSQL (Supabase) - Encrypted at rest              │  │
│  │  ├─ Customers & Profiles                                │  │
│  │  ├─ Policies & Coverage                                 │  │
│  │  ├─ Quotes & Applications                               │  │
│  │  ├─ Claims & Documents                                  │  │
│  │  ├─ Payments & Billing                                  │  │
│  │  ├─ Audit Logs & Security Events                        │  │
│  │  └─ Product Rules & Configuration                       │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

---

### 1.2 Component Architecture

```text
External Services                Core Platform                   Data Stores
(Third-party)                    (Next.js/Supabase)            (PostgreSQL)

┌─────────────┐
│   Stripe    │────────────────┐
│  (Payments) │                │
└─────────────┘                │
                               │
┌─────────────┐                │
│ SendGrid    │────────────────┤
│   (Email)   │                │
└─────────────┘                │    ┌──────────────────────┐
                               │    │  Next.js App Server  │
┌─────────────┐                │    │  ├─ Frontend (React) │
│  Auth0 or   │────────────────┼───→│  ├─ API Routes       │
│ Supabase    │   (Backup)     │    │  ├─ Auth Handler     │
│   (Auth)    │                │    │  └─ Webhooks         │
└─────────────┘                │    └──────────────────────┘
                               │           │
                               │           ↓
┌─────────────┐                │    ┌──────────────────────┐
│  Monitoring │────────────────┤    │ Supabase PostgreSQL  │
│    Tools    │                │    │ ├─ Customers         │
│ (Vercel,    │                │    │ ├─ Policies          │
│  Supabase)  │                │    │ ├─ Quotes            │
└─────────────┘                │    │ ├─ Claims            │
                               │    │ ├─ Payments          │
                               │    │ └─ Audit Logs        │
                               │    └──────────────────────┘
                               │
                               ↓
                        ┌──────────────────────┐
                        │  Storage/Backup      │
                        │  ├─ Supabase Backup  │
                        │  └─ Document Store   │
                        └──────────────────────┘
```

---

### 1.3 Data Flow Architecture

#### User Registration Flow
```text
Customer
  │
  ├─→ Opens portal (Vercel)
  │
  ├─→ Fills registration form
  │
  ├─→ Submits to API (/api/auth/register)
  │
  ├─→ Server validates input
  │     ├─ Email format & uniqueness check (PostgreSQL)
  │     ├─ Password strength validation
  │     └─ Phone format validation
  │
  ├─→ Creates user in Supabase Auth
  │     ├─ Stores encrypted password
  │     ├─ Generates verification token
  │     └─ Stores in auth.users table
  │
  ├─→ Creates customer profile in PostgreSQL
  │     ├─ First name, last name
  │     ├─ Email, phone
  │     ├─ Address details
  │     └─ Consent flags
  │
  ├─→ Sends verification email (SendGrid)
  │     └─ "Confirm your email" link with token
  │
  └─→ Returns to frontend
      └─ Shows "Check your email" message

Customer verifies email
  │
  ├─→ Clicks link in email
  │
  ├─→ Email verified in Supabase
  │
  ├─→ Customer redirected to login
  │
  └─→ Ready to request quote
```

#### Quote Generation Flow
```text
Logged-in Customer
  │
  ├─→ Selects product & enters risk details
  │
  ├─→ Submits quote request to /api/quotes
  │
  ├─→ Server validates input
  │
  ├─→ Checks product rules from PostgreSQL
  │
  ├─→ Applies rating logic
  │     ├─ Base rate lookup
  │     ├─ Apply risk factors
  │     └─ Calculate premium
  │
  ├─→ Validates eligibility
  │     ├─ Age/health checks
  │     ├─ Geographic restrictions
  │     └─ Underwriting rules
  │
  ├─→ Stores quote in PostgreSQL
  │     └─ Linked to customer
  │
  └─→ Returns quote to frontend
      ├─ Premium amount
      ├─ Coverage summary
      ├─ Quote validity
      └─ Next steps (purchase)
```

#### Policy Purchase Flow
```text
Customer reviews quote & decides to buy
  │
  ├─→ Clicks "Purchase" button
  │
  ├─→ Submits policy creation to /api/policies
  │
  ├─→ Server validates
  │     ├─ Quote still valid
  │     ├─ Customer profile complete
  │     └─ Mandatory declarations accepted
  │
  ├─→ Charges payment via Stripe
  │     ├─ Token sent securely
  │     ├─ Amount verified
  │     └─ Charge processed
  │
  ├─→ Stripe returns success/failure
  │
  ├─→ If success:
  │     ├─ Creates policy in PostgreSQL
  │     ├─ Generates policy document
  │     ├─ Stores payment record
  │     ├─ Sends confirmation email (SendGrid)
  │     └─ Shows policy number to customer
  │
  └─→ If failed:
      ├─ Shows error message
      ├─ Allows retry
      └─ Preserves quote for later
```

---

### 1.4 Security Architecture

```text
┌─────────────────────────────────────────────────────────────┐
│                    SECURITY LAYERS                          │
└─────────────────────────────────────────────────────────────┘

LAYER 1: Network Security
┌───────────────────────────────────────────────────────────┐
│ • HTTPS/TLS 1.3 (all traffic encrypted)                  │
│ • Automatic certificate renewal (Let's Encrypt)          │
│ • HSTS (enforce HTTPS)                                   │
│ • CORS (restrict cross-origin requests)                  │
└───────────────────────────────────────────────────────────┘
                         ↓
LAYER 2: Application Security
┌───────────────────────────────────────────────────────────┐
│ • Input validation & sanitization                        │
│ • SQL injection prevention (parameterized queries)       │
│ • XSS prevention (Content Security Policy)               │
│ • CSRF protection (SameSite cookies)                     │
│ • Rate limiting (max 5 login attempts/hour)              │
└───────────────────────────────────────────────────────────┘
                         ↓
LAYER 3: Authentication & Authorization
┌───────────────────────────────────────────────────────────┐
│ • Email/password (with PBKDF2 hashing)                   │
│ • Multi-Factor Authentication (MFA)                      │
│   ├─ FIDO 2.0 / WebAuthn (primary)                       │
│   ├─ TOTP (Google Authenticator)                         │
│   └─ Email OTP (fallback)                                │
│ • JWT tokens (signed, time-limited)                      │
│ • Session management (refresh tokens)                    │
│ • Role-based access control (RBAC)                       │
└───────────────────────────────────────────────────────────┘
                         ↓
LAYER 4: Data Protection
┌───────────────────────────────────────────────────────────┐
│ • Encryption at rest (PostgreSQL native)                 │
│ • Field-level encryption (PII: SSN, payment info)        │
│ • Hashing for sensitive data (one-way)                   │
│ • Row-level security (RLS in PostgreSQL)                 │
│ • Data masking in logs (PII never logged)                │
└───────────────────────────────────────────────────────────┘
                         ↓
LAYER 5: Monitoring & Auditing
┌───────────────────────────────────────────────────────────┐
│ • Audit logs (all API calls logged)                      │
│ • Security event logging                                 │
│ • Failed login tracking                                  │
│ • Policy change history                                  │
│ • Payment transaction logs                               │
│ • Searchable, immutable logs                             │
└───────────────────────────────────────────────────────────┘
```

---

### 1.5 Infrastructure Architecture (Cloud-Agnostic)

```text
┌─────────────────────────────────────────────────────────────────┐
│              VERCEL (Frontend + Backend Hosting)                 │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Edge Network (CDN)                                      │   │
│  │ • Serves static assets from edge                        │   │
│  │ • Reduces latency globally                              │   │
│  │ • Auto HTTPS/TLS 1.3                                    │   │
│  └─────────────────────────────────────────────────────────┘   │
│         │                                        │               │
│         ├─→ Static Pages (.html, .css, .js)     │               │
│         │   ├─ Landing page                      │               │
│         │   ├─ Marketing pages                   │               │
│         │   └─ Policy documents (PDF)            │               │
│         │                                        │               │
│         └─→ Serverless Functions (Node.js)      │               │
│             ├─ API routes (/api/*)               │               │
│             ├─ Auth routes (/api/auth/*)         │               │
│             ├─ Webhook handlers                  │               │
│             └─ Email triggers                    │               │
│                                                  │               │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Environment Variables (Secrets)                         │   │
│  │ • SUPABASE_URL                                          │   │
│  │ • SUPABASE_SERVICE_KEY                                  │   │
│  │ • STRIPE_SECRET_KEY                                     │   │
│  │ • SENDGRID_API_KEY                                      │   │
│  │ • NEXTAUTH_SECRET                                       │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
         │              │                    │
         │              v                    v
         │        ┌─────────────────┐  ┌──────────────────┐
         │        │    Supabase     │  │   SendGrid       │
         │        │   PostgreSQL    │  │   (Email API)    │
         │        │  • Database     │  │                  │
         │        │  • Auth         │  │ Transactional    │
         │        │  • Storage      │  │ Emails for:      │
         │        │                 │  │ • Verification   │
         │        │ Free Tier:      │  │ • Quotes         │
         │        │ • 500MB         │  │ • Confirmations  │
         │        │ • 2 connections │  │ • Policies       │
         │        │ • Auto-backup   │  │ • Claims         │
         │        └─────────────────┘  └──────────────────┘
         │
         └────→ ┌──────────────────┐
               │   Stripe API     │
               │  (Payments)      │
               │                  │
               │ Handles:         │
               │ • Card tokens    │
               │ • Payment charge │
               │ • Webhooks       │
               │ • Receipts       │
               └──────────────────┘
```

---

## Part 2: POC-Specific High-Level Architecture (HLA for POC)

### 2.1 POC Scope & Constraints

**3 User Stories:**
1. `CUST-001` Register account
2. `CUST-004` Request quote
3. `CUST-005` Purchase policy online

**Constraints:**
- Zero-cost infrastructure (free tiers only)
- Single cloud (no multi-cloud complexity)
- Simplified features (minimal configuration)
- Fast deployment (15-minute setup, 4-week dev)
- Security-first (production patterns, not shortcuts)

---

### 2.2 POC Simplified Architecture

```text
┌──────────────────────────────────────────────────────────────┐
│                    POC ARCHITECTURE                          │
│                    (Simplified, Free-Tier)                   │
└──────────────────────────────────────────────────────────────┘

TIER 1: Client Layer
┌──────────────────────────────────────────────────────────────┐
│  Browser → HTTPS → Vercel CDN (static + serverless)          │
│  ├─ React components (register, quote, purchase pages)      │
│  ├─ Form validation (client-side)                           │
│  └─ State management (React hooks)                          │
└──────────────────────────────────────────────────────────────┘
                          │
                          v
TIER 2: API Layer
┌──────────────────────────────────────────────────────────────┐
│  Vercel Functions (Node.js serverless)                       │
│  ├─ /api/auth/register        (CUST-001)                    │
│  ├─ /api/auth/login                                         │
│  ├─ /api/auth/logout                                        │
│  ├─ /api/quotes               (CUST-004)                    │
│  └─ /api/policies             (CUST-005)                    │
│  ├─ Authentication check (JWT)                              │
│  ├─ Input validation (express-validator)                    │
│  └─ Error handling (consistent responses)                   │
└──────────────────────────────────────────────────────────────┘
                          │
         ┌────────────────┼────────────────┐
         │                │                │
         v                v                v
    ┌─────────┐     ┌──────────┐     ┌─────────┐
    │Supabase │     │Supabase  │     │  Stripe │
    │  Auth   │     │PostgreSQL│     │API Test │
    │         │     │          │     │ (no fee)│
    │• Users  │     │• Customers     │         │
    │• Sessions      │• Policies      │• Payment│
    │         │     │• Quotes   │    │ Tokens  │
    │         │     │• Logs     │    │         │
    └─────────┘     └──────────┘     └─────────┘
         │                │                │
         └────────────────┼────────────────┘
                          │
                          v
                   ┌──────────────┐
                   │  SendGrid    │
                   │  Email API   │
                   │              │
                   │ • Signup     │
                   │ • Quote link │
                   │ • Policy     │
                   │ • Receipt    │
                   └──────────────┘
```

---

### 2.3 POC Data Model (Simplified)

```sql
-- Core tables for 3 stories

CREATE TABLE customers (
  id UUID PRIMARY KEY,
  email VARCHAR(255) UNIQUE,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  phone VARCHAR(20),
  address_line1 VARCHAR(255),
  city VARCHAR(100),
  state VARCHAR(50),
  postal_code VARCHAR(20),
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);

CREATE TABLE quotes (
  id UUID PRIMARY KEY,
  customer_id UUID REFERENCES customers(id),
  product_name VARCHAR(100),
  coverage_amount DECIMAL(12,2),
  base_premium DECIMAL(12,2),
  calculated_premium DECIMAL(12,2),
  discount_percent DECIMAL(5,2),
  final_premium DECIMAL(12,2),
  status VARCHAR(50), -- 'pending', 'accepted', 'expired'
  created_at TIMESTAMP,
  expires_at TIMESTAMP
);

CREATE TABLE policies (
  id UUID PRIMARY KEY,
  policy_number VARCHAR(50) UNIQUE,
  customer_id UUID REFERENCES customers(id),
  quote_id UUID REFERENCES quotes(id),
  product_name VARCHAR(100),
  premium_amount DECIMAL(12,2),
  effective_date DATE,
  expiry_date DATE,
  status VARCHAR(50), -- 'active', 'pending', 'expired'
  created_at TIMESTAMP
);

CREATE TABLE payments (
  id UUID PRIMARY KEY,
  policy_id UUID REFERENCES policies(id),
  stripe_transaction_id VARCHAR(255),
  amount DECIMAL(12,2),
  currency VARCHAR(3),
  status VARCHAR(50), -- 'pending', 'completed', 'failed'
  created_at TIMESTAMP
);

CREATE TABLE audit_logs (
  id UUID PRIMARY KEY,
  user_id UUID,
  action VARCHAR(100), -- 'register', 'quote_request', 'purchase'
  resource_type VARCHAR(50), -- 'customer', 'quote', 'policy'
  resource_id UUID,
  details JSONB,
  created_at TIMESTAMP
);
```

---

### 2.4 POC Deployment Flow

```text
Developer
  │
  ├─→ Develops locally (Next.js dev server)
  │   ├─ npm install
  │   ├─ npm run dev
  │   └─ Tests on http://localhost:3000
  │
  ├─→ Commits to GitHub
  │
  ├─→ Vercel auto-triggers build
  │   ├─ Clones repo
  │   ├─ Installs dependencies
  │   ├─ Runs tests (if configured)
  │   ├─ Builds Next.js app
  │   └─ Deploys to Vercel edge
  │
  ├─→ Creates preview URL
  │   └─ reviewers.vercel.app (for PR review)
  │
  ├─→ When merged to main:
  │   └─ Auto-deploys to production
  │       └─ insurance-poc.vercel.app
  │
  └─→ Stakeholders access via live URL
      └─ Zero-downtime deployments
```

---

### 2.5 POC Environment Setup (15 minutes)

**Step 1: Create Vercel Account (2 min)**
- Go to vercel.com
- Sign up with GitHub account
- Grant access to GitHub repo

**Step 2: Create Supabase Account (2 min)**
- Go to supabase.io
- Create project (free tier)
- Get connection string

**Step 3: Configure Environment Variables (3 min)**
```bash
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=xxx
STRIPE_PUBLIC_KEY=pk_test_xxx
STRIPE_SECRET_KEY=sk_test_xxx
SENDGRID_API_KEY=SG.xxx
NEXTAUTH_SECRET=random-secret
NEXTAUTH_URL=https://insurance-poc.vercel.app
```

**Step 4: Deploy (5 min)**
```bash
git push origin main
# Vercel auto-deploys
# Live in ~2 minutes
```

**Step 5: Test (3 min)**
- Open insurance-poc.vercel.app
- Register account
- Request quote
- Purchase policy

---

### 2.6 POC System Components

```text
┌─────────────────────────────────────────────────────────────┐
│                  COMPONENT BREAKDOWN                        │
│                    (POC Only)                               │
└─────────────────────────────────────────────────────────────┘

Component                Usage                    For Stories
─────────────────────────────────────────────────────────────
Vercel Hosting          Frontend + API routes    All
NextAuth.js             Authentication           CUST-001
Supabase Auth           User identity            CUST-001
Supabase PostgreSQL     Data storage             All
Email validation        Verify signup            CUST-001
Quote calculation       Generate quote           CUST-004
Stripe (test)           Payment simulation       CUST-005
SendGrid                Transactional email      All
Vercel Logs             Debugging/monitoring     All
Supabase Logs           Database activity        All

Not included in POC (for future):
─────────────────────────────────────────────────────────────
Claims management       (requires CUST-011)
Field agent portal      (requires AGENT-003)
Document generation     (can use simple HTML-to-PDF)
Advanced reporting      (dashboards for PM)
Multi-currency support  (hardcode USD for POC)
```

---

## Part 3: POC Implementation Task List

### Phase 1: Foundation (Week 1)

#### Task 1.1 Environment Setup
- [ ] Create Vercel account and link GitHub
- [ ] Create Supabase project
- [ ] Generate API keys (Stripe, SendGrid, Supabase)
- [ ] Create .env.local with all secrets
- [ ] Test local development environment (npm run dev)

**Owner:** Backend Lead  
**Effort:** 2 hours  
**Dependencies:** None

---

#### Task 1.2 Database Schema
- [ ] Create PostgreSQL schema in Supabase
  - [ ] customers table
  - [ ] quotes table
  - [ ] policies table
  - [ ] payments table
  - [ ] audit_logs table
- [ ] Add indexes on frequently-queried fields
- [ ] Set up Row-Level Security (RLS) policies
- [ ] Create sample data for testing

**Owner:** Database Administrator  
**Effort:** 4 hours  
**Dependencies:** Task 1.1

---

#### Task 1.3 Project Scaffolding
- [ ] Create Next.js project with TypeScript
- [ ] Configure ESLint and Prettier
- [ ] Set up folder structure
  ```
  /app
    /api
      /auth
        register.ts
        login.ts
        logout.ts
      /quotes
        route.ts
      /policies
        route.ts
    /components
      RegisterForm.tsx
      QuoteForm.tsx
      PolicySummary.tsx
    /pages
      register.tsx
      quote.tsx
      purchase.tsx
  /lib
    supabase.ts
    stripe.ts
    auth.ts
  /styles
    globals.css
  ```
- [ ] Deploy skeleton to Vercel
- [ ] Confirm auto-deployment works

**Owner:** Frontend Lead  
**Effort:** 3 hours  
**Dependencies:** Task 1.1

---

### Phase 2: Authentication (Week 1–2)

#### Task 2.1 NextAuth.js Setup
- [ ] Install NextAuth.js dependencies
- [ ] Configure JWT strategy
- [ ] Set up Supabase as credential provider
- [ ] Create /api/auth/[...nextauth].ts
- [ ] Test local authentication

**Owner:** Backend Lead  
**Effort:** 4 hours  
**Dependencies:** Task 1.2, Task 1.3

---

#### Task 2.2 Registration Flow (CUST-001)
- [ ] Create RegisterForm component
  - [ ] Email field
  - [ ] Password field (with strength indicator)
  - [ ] First name, last name
  - [ ] Phone number
  - [ ] Address fields
  - [ ] Consent checkbox
  - [ ] Form validation (client-side)
- [ ] Create /api/auth/register endpoint
  - [ ] Validate input (server-side)
  - [ ] Check email uniqueness
  - [ ] Hash password
  - [ ] Create user in Supabase Auth
  - [ ] Create customer profile in PostgreSQL
  - [ ] Send verification email (SendGrid)
- [ ] Email template for verification
- [ ] Test end-to-end registration

**Owner:** Full Stack  
**Effort:** 8 hours  
**Dependencies:** Task 2.1

---

#### Task 2.3 Login Flow
- [ ] Create LoginForm component
- [ ] Create /api/auth/login endpoint
- [ ] Test session management
- [ ] Implement "forgot password" link (UI only for POC)

**Owner:** Full Stack  
**Effort:** 4 hours  
**Dependencies:** Task 2.1

---

#### Task 2.4 MFA Setup (FIDO2 + TOTP)
- [ ] Install WebAuthn libraries (simplewebauthn)
- [ ] Create FIDO2 registration endpoint
- [ ] Create FIDO2 authentication endpoint
- [ ] Install TOTP library (speakeasy)
- [ ] Create TOTP setup endpoint
- [ ] Create TOTP verification endpoint
- [ ] Test MFA flows
- [ ] Update login form to show MFA options

**Owner:** Security Lead  
**Effort:** 8 hours  
**Dependencies:** Task 2.1

---

### Phase 3: Core Business Logic (Week 2–3)

#### Task 3.1 Quote Engine (CUST-004)
- [ ] Create QuoteForm component
  - [ ] Product selection
  - [ ] Risk details input (coverage amount, etc.)
  - [ ] Form validation
- [ ] Create /api/quotes endpoint
  - [ ] Input validation
  - [ ] Fetch product rules from database
  - [ ] Calculate base premium
  - [ ] Apply risk factors
  - [ ] Apply discounts
  - [ ] Validate eligibility
  - [ ] Store quote in PostgreSQL
  - [ ] Return quote to frontend
- [ ] Create quote display component
  - [ ] Premium amount
  - [ ] Coverage summary
  - [ ] Validity period
  - [ ] "Purchase" button
- [ ] Test quote generation with various inputs

**Owner:** Full Stack  
**Effort:** 10 hours  
**Dependencies:** Task 2.3 (logged-in user)

---

#### Task 3.2 Policy Creation & Purchase (CUST-005)
- [ ] Create purchase confirmation form
  - [ ] Review quote details
  - [ ] Accept terms & conditions checkbox
  - [ ] Accept insurance terms checkbox
- [ ] Create Stripe integration
  - [ ] Install @stripe/stripe-js
  - [ ] Create payment form component
  - [ ] Tokenize card details securely
- [ ] Create /api/policies endpoint
  - [ ] Validate quote validity
  - [ ] Validate customer profile completeness
  - [ ] Validate declarations acceptance
  - [ ] Call Stripe API to charge payment
  - [ ] Handle Stripe response
  - [ ] If success: create policy in PostgreSQL
  - [ ] Generate policy number
  - [ ] Send confirmation email (SendGrid)
  - [ ] Return policy to frontend
- [ ] Create policy summary display
  - [ ] Policy number
  - [ ] Coverage details
  - [ ] Effective date
  - [ ] "Download policy" button
- [ ] Test full purchase flow end-to-end

**Owner:** Full Stack  
**Effort:** 12 hours  
**Dependencies:** Task 3.1

---

### Phase 4: Integration & Polish (Week 4)

#### Task 4.1 Email Notifications
- [ ] Create SendGrid templates
  - [ ] Signup verification email
  - [ ] Quote confirmation email
  - [ ] Policy issuance email
  - [ ] Payment receipt email
- [ ] Create email utility functions
- [ ] Test email delivery
- [ ] Verify emails appear in inbox

**Owner:** Full Stack  
**Effort:** 4 hours  
**Dependencies:** Task 2.2, Task 3.2

---

#### Task 4.2 Error Handling & Validation
- [ ] Add try-catch to all API endpoints
- [ ] Create consistent error response format
  ```json
  {
    "success": false,
    "error": "Email already registered",
    "code": "DUPLICATE_EMAIL"
  }
  ```
- [ ] Test error flows
- [ ] Add user-friendly error messages to frontend

**Owner:** Full Stack  
**Effort:** 4 hours  
**Dependencies:** All APIs

---

#### Task 4.3 Security Hardening
- [ ] Enable HTTPS/TLS 1.3 (Vercel default)
- [ ] Set up CORS policies
  - [ ] Allow only production domain
- [ ] Implement rate limiting
  - [ ] 5 failed login attempts per hour
  - [ ] 10 quote requests per day per user
- [ ] Add input sanitization
  - [ ] Escape HTML entities
  - [ ] Validate email format
  - [ ] Validate phone format
- [ ] Set up Content Security Policy (CSP) headers
- [ ] Test security with simple attack scenarios

**Owner:** Security Lead  
**Effort:** 6 hours  
**Dependencies:** All APIs

---

#### Task 4.4 Monitoring & Logging
- [ ] Set up Vercel Analytics
- [ ] Create audit logging
  - [ ] Log all API calls (user_id, action, timestamp)
  - [ ] Log authentication events
  - [ ] Log payment transactions
- [ ] Create CloudWatch-equivalent logging (using Vercel + Supabase)
- [ ] Set up basic alerting
  - [ ] Email on critical errors
  - [ ] Log retention policy (30 days for POC)

**Owner:** DevOps Lead  
**Effort:** 4 hours  
**Dependencies:** All APIs

---

#### Task 4.5 Testing & QA
- [ ] Manual testing checklist
  - [ ] Register account
  - [ ] Verify email
  - [ ] Login with MFA
  - [ ] Request quote
  - [ ] Purchase policy with test card
  - [ ] Verify emails received
  - [ ] Check audit logs
- [ ] Performance testing
  - [ ] Lighthouse score >80
  - [ ] API response time <500ms
- [ ] Security testing
  - [ ] SQL injection attempt
  - [ ] XSS attempt
  - [ ] CSRF token check
  - [ ] Rate limiting validation

**Owner:** QA Lead  
**Effort:** 8 hours  
**Dependencies:** Tasks 4.1–4.4

---

#### Task 4.6 Documentation & Demo Prep
- [ ] Create user guide (how to use POC)
- [ ] Create admin guide (how to access logs, test data)
- [ ] Create API documentation
- [ ] Record demo video (5 min walkthrough)
- [ ] Prepare stakeholder presentation
  - [ ] System architecture diagram
  - [ ] User flow diagrams
  - [ ] Demo script
- [ ] Create deployment runbook

**Owner:** Documentation Lead  
**Effort:** 6 hours  
**Dependencies:** Task 4.5

---

### Task Summary

| Phase | Tasks | Hours | Cumulative |
|-------|-------|-------|-----------|
| **Phase 1** | 3 tasks (setup) | 9 | 9 |
| **Phase 2** | 4 tasks (auth) | 24 | 33 |
| **Phase 3** | 2 tasks (business logic) | 22 | 55 |
| **Phase 4** | 6 tasks (integration) | 32 | 87 |
| **Total** | 15 tasks | **87 hours** | |

---

### Resource Plan

**Team Size: 4–5 people**

| Role | FTE | Tasks |
|------|-----|-------|
| Backend Lead | 100% | Tasks 1.1, 2.1, 3.1, 3.2, 4.1, 4.2 |
| Frontend Lead | 100% | Tasks 1.3, 2.2, 2.3, 3.1, 3.2 |
| Security Lead | 50% | Tasks 2.4, 4.3, 4.5 |
| DevOps Lead | 50% | Tasks 1.1, 4.4 |
| QA Lead | 50% | Tasks 4.5, 4.6 |
| **PM/BA** | 25% | Coordination, stakeholder updates |

**Timeline: 4 weeks**

---

## Part 4: Risk Mitigation & Success Criteria

### POC Success Criteria

✅ **Functional**
- Registration works end-to-end
- Quote generation with correct math
- Payment processing successful
- Emails delivered

✅ **Performance**
- Page load: <3 seconds
- API response: <500ms
- 99.9% uptime

✅ **Security**
- HTTPS on all endpoints
- MFA working
- Audit logs complete
- No sensitive data in logs

✅ **User Experience**
- Intuitive UI
- Clear error messages
- Responsive design (mobile-friendly)

---

### Known Risks & Mitigations

| Risk | Probability | Impact | Mitigation |
|------|------------|--------|-----------|
| Supabase free tier limits (500MB, 2 connections) | Medium | Low | Start with small test data; plan upgrade if needed |
| Vercel function timeout (12s) | Low | Low | Monitor quote calculation time; optimize if needed |
| SendGrid free tier emails go to spam | Medium | Low | Test email deliverability early; use template defaults |
| Stripe test mode limitations | Low | Low | Use test credit cards; understand test mode sandbox |
| Team unfamiliar with Next.js | High | Medium | Schedule tech training early; pair programming |
| Scope creep (add more than 3 stories) | Medium | High | Strict task list; defer out-of-scope work to Phase 2 |

---

## Conclusion

**This HLA provides:**
1. ✅ Complete system architecture for insurance platform
2. ✅ POC-specific simplified architecture
3. ✅ Free-tier technology stack (Vercel + Supabase)
4. ✅ Detailed task breakdown (15 tasks, 87 hours)
5. ✅ 4-week timeline with 4–5 person team
6. ✅ Security-first design from day 1
7. ✅ Clear success criteria and risk mitigation

**Next Steps:**
1. Approve this architecture
2. Allocate team resources
3. Kick off Phase 1 (Week 1)
4. Demo to stakeholders (Week 5)
